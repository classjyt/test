import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'
import { defineStore } from '#imports';

export const useDownloadStore = defineStore('download', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateDownloadBannerList = (list: any[]) => {
        bannerList.value = list
    }

    const queryDownloadBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: 'f6854W6A',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateDownloadBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateDownloadBannerList,
        queryDownloadBannerList,
    }
})
