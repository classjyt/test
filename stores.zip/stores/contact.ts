import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'
import { defineStore } from '#imports';

export const useContactStore = defineStore('contact', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateContactBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const queryContactBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: 'uSPcDeMu',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateContactBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateContactBannerList,
        queryContactBannerList,
    }
})
