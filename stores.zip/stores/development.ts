import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'
import { defineStore } from '#imports';

export const useDevelopmentStore = defineStore('development', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateDevelopmentBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const queryDevelopmentBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: 'SkcXecMu',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateDevelopmentBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateDevelopmentBannerList,
        queryDevelopmentBannerList,
    }
})
