import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'

export const useProductStore = defineStore('product', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateProductBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const queryProductBannerList = async () => {
        const params = {
            locationCodes: 'uaSduFhT',
            pageNum: 1,
            pageSize: 10,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateProductBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateProductBannerList,
        queryProductBannerList,
    }
})
