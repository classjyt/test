import { useHttp } from '~/composables/useHttp'
import { defineStore } from 'pinia'
import { computed, ref, watch } from 'vue'
import { useNuxtApp } from 'nuxt/app'

interface MenuItem {
    id: number
    name: string
    // 添加其他菜单项需要的属性
    [key: string]: any
}

const defaultMenuList = [
    {
        name: '首页',
        href: '/',
        code: '2b7G6hM1',
    },
    {
        name: '关于我们',
        href: '/about/company',
        code: '9X5vN3rJ',
        itemMenuList: [
            {
                name: '公司概况',
                href: '/about/company',
                code: '1gK9L7cN',
            },
            {
                name: '历史',
                href: '/about/history',
                code: '8M6tH1vR',
            },
            {
                name: '价值体系',
                href: '/about/values',
                code: '3n7FqP4j',
            },
        ],
    },
    {
        name: '产品与服务',
        href: '/product/product',
        code: '4L2dF8kS',
        itemMenuList: [
            {
                name: '船舶产品',
                href: '/product/product',
                code: '5Y9kD2wS',
            },
            {
                name: '技术创新与优势',
                href: '/product/service',
                code: 'x8Q3rG5f',
            },
        ],
    },
    {
        name: '新闻动态',
        href: '/news/company-news',
        code: '1q6W4zP9',
        itemMenuList: [
            {
                name: '公司新闻',
                href: '/news/company-news',
                code: '9bZ3mK6s',
            },
            {
                name: '公告栏',
                href: '/news/notice',
                code: '2D5wLp7X',
            },
            {
                name: '媒体聚焦',
                href: '/news/report',
                code: '4vR6yH9M',
            },
        ],
    },
    {
        name: '党建活动',
        href: '/party-building/overview',
        code: '5c2V9nR6',
        itemMenuList: [
            {
                name: '党建概况',
                href: '/party-building/overview',
                code: '7w5Nv3Lk',
            },
            // {
            //     name: '党建动态',
            //     href: '/party-building/activities',
            //     code: '4P8hJ2dG',
            // },
            {
                name: '党员风采',
                href: '/party-building/exemplary-conduct',
                code: '9s3Bm6rF',
            },
            // {
            //     name: '党建活动与成果',
            //     href: '/party-building/outcomes',
            //     code: '2v7Tk5Yq',
            // },
            // {
            //     name: '党建大事记',
            //     href: '/party-building/big-event',
            //     code: '6X4pZ8bW',
            // },
        ],
    },
    // { name: '社会公益', href: '/social-welfare', code: '9bI0W4F2' },
    // { name: '可持续发展', href: '/development', code: 'y6D9Q1fM' },
    { name: '人才招聘', href: 'https://jobs.hengli.com/', code: '3H8j4pX7', target: '_blank' },
    { 
        name: '联系我们', 
        href: '/contact', 
        code: '8K7mT3gB',
    },
    {
        name: '下载中心', 
        href: '/download', 
        code: 'S4AWE6w7',
    }
]


export const useHeaderStore = defineStore('header', () => {
    const { $i18n } = useNuxtApp()
    // State
    const menuList = ref<MenuItem[]>([])
    const locale = ref($i18n.locale.value)
    const loading = ref(false)
    const error = ref<Error | null>(null)

    // Getters
    const hasMenus = computed(() => menuList.value.length > 0)

    watch(locale.value, (newVal, oldVal) => {
        // console.error('newVal :>> ', newVal);
        if (newVal !== oldVal) {
            queryMenuList()
        }
    })

    // Actions
    const updateMenuList = (list: MenuItem[]) => {
        // console.log('newMenuList :>> ', list);
        const newMenuList = defaultMenuList?.map((item) => {
            const menu = list?.find((v) => v.code === item.code)

            if (item?.itemMenuList && menu?.itemMenuList) {
                item.itemMenuList = item.itemMenuList?.map((item) => {
                    const subMenu = menu.itemMenuList?.find((v) => v.code === item.code)

                    const newItem = {
                        ...subMenu,
                        ...item,
                    }
                    // console.log('newItem :>> ', newItem);
                    return newItem
                })
            }

            const newItem = {
                ...menu,
                ...item,
            }
            // console.log('newItem :>> ', newItem);
            return newItem
        })
        // console.log('newMenuList :>> ', newMenuList);
        menuList.value = newMenuList
    }

    const queryMenuList = async () => {
        try {
            loading.value = true
            error.value = null

            const params = {
                websiteCode: 3,
            }

            const { data, error: fetchError } = await useHttp<{
                data: {
                    websiteVOList?: Array<{
                        websiteInfoVOList?: Array<{
                            menuList?: MenuItem[]
                        }>
                    }>
                }
            }>('/website/location/websiteTree', params)

            if (fetchError.value) {
                throw fetchError.value
            }
            console.log('菜单树数据 :>> ', data.value?.data);
            const newMenuList = data.value?.data?.websiteVOList?.[0]?.websiteInfoVOList?.[0]?.menuList || []
            updateMenuList(newMenuList)

            return newMenuList
        } catch (err) {
            error.value = err as Error
            // console.error('Failed to fetch menu list:', err)
            return []
        } finally {
            loading.value = false
        }
    }

    return {
        menuList,
        loading,
        error,
        hasMenus,
        updateMenuList,
        queryMenuList,
    }
})
