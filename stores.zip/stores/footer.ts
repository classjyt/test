import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'
import { useNuxtApp } from 'nuxt/app'

interface MenuItem {
    id: number
    name: string
    // 添加其他菜单项需要的属性
    [key: string]: any
}

export const useFooterStore = defineStore('footer', () => {
    // State
    const companyInfo = ref<object>({})
    const loading = ref(false)

    // Actions
    const updateCompanyInfo = (info: MenuItem[]) => {
        // console.log('companyInfo :>> ', info);
        companyInfo.value = info
    }

    const queryCompanyInfo = async () => {
        const { $i18n } = useNuxtApp()
        const locale = $i18n.locale.value
        try {
            loading.value = true

            const params = {
                websiteCode: 3,
                language: locale === 'zh' ? '1' : '2'
            }

            const response = await CommonService.queryCompanyInfo(params)

            const newCompanyInfo = response.data.value?.data || {}
            updateCompanyInfo(newCompanyInfo)

            return newCompanyInfo
        } catch (err) {
            // console.error('Failed to fetch company info:', err)
            return []
        } finally {
            loading.value = false
        }
    }

    return {
        companyInfo,
        loading,
        updateCompanyInfo,
        queryCompanyInfo,
    }
})
