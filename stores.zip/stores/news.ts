import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'

export const useNewsStore = defineStore('news', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateNewsBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const queryNewsBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: 'uaeiuFhT',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateNewsBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateNewsBannerList,
        queryNewsBannerList,
    }
})
