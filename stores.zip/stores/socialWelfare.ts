import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
// import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import CommonService from '../service/common'

export const useSocialWelfareStore = defineStore('socialWelfare', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateSocialWelfareBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const querySocialWelfareBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: '',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateSocialWelfareBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateSocialWelfareBannerList,
        querySocialWelfareBannerList,
    }
})
