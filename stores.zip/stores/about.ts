import ImgService from '~/service/img';
import { useHttp } from '~/composables/useHttp'
import { computed, ref } from 'vue'
import CommonService from '../service/common'
import { defineStore } from '#imports';

export const useAboutStore = defineStore('about', () => {
    // State
    const bannerList = ref<any[]>([])

    // Actions
    const updateAboutBannerList = (list: any[]) => {
        // console.log('companyInfo :>> ', list);
        bannerList.value = list
    }

    const queryAboutBannerList = async () => {
        const params = {
            keyword: '',
            locationCodes: 'uapiuFhT',
            pageNum: 1,
            pageSize: 200,
            status: 1,
        }
        const response = await ImgService.queryImgList(params)
        updateAboutBannerList(response.data.value?.rows)
    }

    return {
        bannerList,
        updateAboutBannerList,
        queryAboutBannerList,
    }
})
