<template>
    <DefaultLayout>
        <SubHeader
            :title="'联系我们'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'

const navList = ref([])

import { storeToRefs, useContactStore } from '#imports'
const contactStore = useContactStore()
const { bannerList } = storeToRefs(contactStore)

</script>

<style scoped>
</style>
