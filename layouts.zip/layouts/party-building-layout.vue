<template>
    <DefaultLayout>
        <SubHeader
            :title="'党建活动'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'

const navList = ref([
    { name: '党建概况', path: '/party-building/overview' },
    { name: '党建动态', path: '/party-building/activities' },
    { name: '党员风采', path: '/party-building/exemplary-conduct' },
    { name: '党建活动与成果', path: '/party-building/outcomes' },
    { name: '党建大事记', path: '/party-building/big-event' },
])

import { storeToRefs, usePartyBuildingStore } from '#imports'
const partyBuildingStore = usePartyBuildingStore()
const { bannerList } = storeToRefs(partyBuildingStore)

// const bannerList = ref([
//     {
//         pcImgUrl: '/images/party-building/banner1.gif',
//     }
// ])

</script>

<style scoped>
</style>
