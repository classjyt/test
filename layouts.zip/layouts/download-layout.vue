<template>
    <DefaultLayout>
        <SubHeader
            :title="'下载中心'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'
import { storeToRefs, useDownloadStore } from '#imports'

const navList = ref([])
const downloadStore = useDownloadStore()
const { bannerList } = storeToRefs(downloadStore)

</script>

<style scoped>
</style>
