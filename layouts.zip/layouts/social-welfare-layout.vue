<template>
    <DefaultLayout>
        <!-- <SubHeader
            :title="'社会公益'"
            :navList="navList"
            :bannerList="bannerList"
        /> -->
        <slot />
    </DefaultLayout>
</template>

<script setup>
import DefaultLayout from './default'

import { storeToRefs, useDevelopmentStore } from '#imports'
const developmentStore = useDevelopmentStore()
const { bannerList } = storeToRefs(developmentStore)

</script>

<style scoped>
</style>
