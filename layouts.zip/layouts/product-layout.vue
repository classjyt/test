<template>
    <DefaultLayout>
        <SubHeader
            :title="'产品与服务'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'

const navList = ref([
    { name: '船舶产品', path: '/product/product' },
    { name: '技术与创新优势', path: '/product/service' },
])

import { storeToRefs, useProductStore } from '#imports'
const productStore = useProductStore()
const { bannerList } = storeToRefs(productStore)

</script>

<style scoped>
</style>
