<template>
    <DefaultLayout>
        <SubHeader
            :title="'可持续发展'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'

const navList = ref([])

import { storeToRefs, useDevelopmentStore } from '#imports'
const developmentStore = useDevelopmentStore()
const { bannerList } = storeToRefs(developmentStore)

</script>

<style scoped>
</style>
