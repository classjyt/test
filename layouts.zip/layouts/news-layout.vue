<template>
    <DefaultLayout>
        <SubHeader
            :title="'新闻动态'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'

const navList = ref([
    { name: '公司新闻', path: '/news/company-news' },
    { name: '公告栏', path: '/news/notice' },
    { name: '媒体聚焦', path: '/news/report' },
])

import { storeToRefs, useNewsStore } from '#imports'
const newsStore = useNewsStore()
const { bannerList } = storeToRefs(newsStore)

</script>

<style scoped>
</style>
