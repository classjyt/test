<template>
    <DefaultLayout>
        <SubHeader
            :title="'关于我们'"
            :navList="navList"
            :bannerList="bannerList"
        />
        <slot />
    </DefaultLayout>
</template>

<script setup>
import { SubHeader } from '#components'
import DefaultLayout from './default'
import { useI18n, storeToRefs, useAboutStore } from '#imports'
// const { localePath } = useI18n()

const navList = ref([
    { name: '公司概况', path: '/about/company' },
    { name: '历史', path: '/about/history' },
    { name: '价值体系', path: '/about/values' },
])

const aboutStore = useAboutStore()
const { bannerList } = storeToRefs(aboutStore)

</script>

<style scoped>
</style>
