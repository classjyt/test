<template>
    <DefaultLayout>
        <div class="h-pt-[60px] md:h-pt-20">
            <Back />
        </div>
        <slot />
    </DefaultLayout>
</template>

<script setup>
import DefaultLayout from './default'

</script>

<style scoped>
</style>
