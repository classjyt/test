// locales/en-US.ts
export default {
    common: {
        companyName: 'HENGLI HEAVY INDUSTRIES',
        more: 'More',
        learnMore: 'More',
        address: 'Address',
        phone: 'Phone',
        fax: 'Fax',
        email: 'Email',
        website: 'Website',
        searchPlaceholder: 'search value',
        view: 'view',
    },
    home: {
        productTitle: 'Ship Types and Technical Strength',
        companyStatus: 'Company Status',
        companyNews: 'Company News',
    },
    about: {
        companyProfile: 'Company Profile',
        companyStatus: 'Company Status',
        history: 'History',
        missionAndVision: 'Mission & Vision',
        coreValues: 'Core Values',
        slogan: 'Slogan',
    },
    product: {
        shipProducts: 'Ship Products',
    },
    news: {
        companyNews: 'Company News',
        announcements: 'Announcements',
        specialReports: 'Special Reports',
    },
    partyBuilding: {

    },
    development: {
        environmentalProtection: 'Environmental Protection',
        greenTechnologyInnovation: 'Green Technology Innovation',
        socialResponsibility: 'Social Responsibility',
        sustainableOperations: 'Sustainable Operations',
        esgReportsAndTargets: 'ESG Reports and Targets',
        esgReportsDownload: 'ESG Reports Download',
    },
    footer: {
        copyright: 'Copyright © 2022 - {year} Hengli Heavy Industry Co., Ltd. All Rights Reserved'
    }
}
