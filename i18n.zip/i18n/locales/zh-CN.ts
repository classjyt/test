// locales/zh-CN.ts
export default {
    common: {
        companyName: '恒力重工集团',
        more: '更多',
        learnMore: '了解更多',
        address: '地址',
        phone: '电话',
        fax: '传真',
        email: '邮箱',
        website: '网址',
        searchPlaceholder: '搜索内容',
        view: '查看',
    },
    home: {
        productTitle: '船型产品及技术实力',
        companyStatus: '公司现状',
        companyNews: '公司新闻',
    },
    about: {
        companyProfile: '公司简介',
        companyStatus: '公司现状',
        history: '历史',
        missionAndVision: '使命与愿景',
        coreValues: '核心价值',
        slogan: '口号',
    },
    product: {
        shipProducts: '船舶产品',
    },
    news: {
        companyNews: '公司新闻',
        announcements: '公告栏',
        specialReports: '媒体聚焦',
    },
    partyBuilding: {

    },
    development: {
        environmentalProtection: '环境保护',
        greenTechnologyInnovation: '绿色技术创新',
        socialResponsibility: '社会责任',
        sustainableOperations: '可持续运营',
        esgReportsAndTargets: 'ESG报告与目标',
        esgReportsDownload: 'ESG报告下载',
    },
    footer: {
        copyright: 'Copyright © 2022-{year} by 恒力重工集团有限公司版权所有 All Right Reserved'
    }
}
