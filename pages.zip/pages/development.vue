<template>
    <div class="development-page h-box-content h-w-full">
        <!-- 环境保护 -->
        <div class="wrap-y-top common-wrap">
            <div
                data-aos="slide-right"
                class="title">
                {{ t('development.environmentalProtection') }}
            </div>
            <Swiper
                data-aos="slide-up"
                :modules="[Autoplay, Navigation, Pagination]"
                :slides-per-view="0"
                :loop="true"
                effect="flip"
                :autoplay="{ delay: 2000 }"
                :pagination="{
                    clickable: true,
                    el: '.swiper-pagination-one',
                }"
                :breakpoints="{
                    320: { slidesPerView: 1, spaceBetween: 16 },
                    640: { slidesPerView: 1.5, spaceBetween: 16 },
                    768: { slidesPerView: 2, spaceBetween: 40 },
                    1024: { slidesPerView: 3, spaceBetween: 40 },
                }"
                class="mySwiper h-w-full !h-m-0">
                <SwiperSlide
                    v-for="(item, index) in envList?.rows"
                    class="!h-flex h-flex-col h-justify-between h-px-4 h-py-7 h-w-full !h-h-[188px] h-border h-border-b-2 h-border-[#DCDFE6] h-rounded md:h-rounded-lg md:h-px-[60px] md:h-py-10 md:!h-h-[280px] xl:h-py-[60px] xl:!h-h-[360px]"
                    :key="index">
                    <div class="h-h-12 h-flex h-justify-center h-items-center md:h-h-[52px] lg:h-h-[68px]">
                        <!-- <NuxtImg
                            :class="[item.excerpt ? 'h-h-6 h-w-6 md:h-h-7 md:h-w-7 xl:h-w-9 xl:h-h-9' : 'h-h-12 h-w-12 md:h-w-[52px] md:h-h-[52px] xl:h-w-[68px] xl:h-h-[68px]']"
                            :src="item.pcImgUrl" /> -->
                        <LottieImage
                            :class="[item.excerpt ? 'h-h-6 h-w-6 md:h-h-7 md:h-w-7 xl:h-w-9 xl:h-h-9' : 'h-h-12 h-w-12 md:h-w-[52px] md:h-h-[52px] xl:h-w-[68px] xl:h-h-[68px]']"
                            :src="item.pcImgUrl" />
                    </div>
                    <div class="h-text-center h-mt-auto">
                        <div class="h-text-sm h-font-medium md:h-text-lg h-line-clamp-1">{{ item.title }}</div>
                        <div class="h-mt-2 h-text-xs h-text-secondary md:h-text-sm xl:h-text-base xl:h-mt-4 h-line-clamp-2 h-text-justify">{{ item.subtitle }}</div>
                    </div>
                </SwiperSlide>
            </Swiper>
            <!-- Swiper 默认样式分页器外置容器 -->
            <div class="swiper-pagination-one h-mt-4 h-text-center"></div>
        </div>

        <!-- 绿色技术创新 -->
        <div class="common-wrap wrap-y-center !h-pt-0">
            <div
                data-aos="slide-right"
                class="title md:h-w-full">
                {{ t('development.greenTechnologyInnovation') }}
            </div>
            <div
                data-aos="slide-up"
                class="h-flex h-flex-col md:h-flex-row md:h-items-start md:h-rounded-lg h-overflow-hidden">
                <div class="h-flex h-flex-col h-rounded-lg h-bg-[#EEF2F7E5] h-px-5 h-py-8 md:h-pb-6 md:h-px-7 md:h-w-[384px] md:h-h-[390px] md:h-rounded-none xl:h-h-[600px] xl:h-px-[60px] xl:h-pt-[100px] xl:h-pb-[60px] xl:h-w-[572px] md:h-order-2">
                    <div :key="realIndex1" data-aos="slide-up" class="h-flex h-items-center h-text-base h-font-medium h-text-primary md:h-text-2xl xl:h-text-[28px]">{{ green?.rows[realIndex1]?.title }}</div>
                    <ElScrollbar :key="realIndex1" data-aos="slide-up" class="h-my-10 h-text-sm xl:h-flex-1 xl:h-mb-14 xl:h-text-base h-text-justify">
                        {{ green?.rows[realIndex1]?.subtitle }}
                    </ElScrollbar>
                    <div
                        class="h-mt-auto h-flex"
                        v-if="green?.rows?.length > 1">
                        <div
                            class="h-flex h-justify-center h-items-center h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary h-mr-3"
                            @click="() => elCarouselRef1?.prev()">
                            <span class="iconfont icon-zuojiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                        <div
                            class="h-flex h-justify-center h-items-center h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary"
                            @click="() => elCarouselRef1?.next()">
                            <span class="iconfont icon-icon_jiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                    </div>
                </div>
                <div class="h-group h-overflow-hidden h-relative h-rounded-md h-w-full h-h-[206px] h-mt-3 md:h-mt-0 md:h-h-[390px] md:h-rounded-none md:h-flex-1 xl:h-h-[600px] md:h-order-1">
                    <el-carousel
                        ref="elCarouselRef1"
                        trigger="click"
                        class="h-h-full"
                        height="100%"
                        indicator-position="none"
                        :autoplay="true"
                        interval="4000"
                        arrow="never">
                        <el-carousel-item
                            v-for="(item, index) in green?.rows"
                            :key="index">
                            <!-- <NuxtImg
                                class="h-w-full h-h-full h-object-cover"
                                :src="item.pcImgUrl" /> -->
                            <LottieImage
                                class="h-w-full h-h-full h-object-cover hover-item-img"
                                :src="item.pcImgUrl" />
                        </el-carousel-item>
                    </el-carousel>
                </div>
            </div>
        </div>
        <!-- 社会责任 -->
        <div class="h-relative wrap-y-center">
            <NuxtImg
                class="h-absolute -h-z-10 h-top-0 h-left-0 h-h-full h-w-full h-bg-center h-object-cover"
                src="/images/social/responsibility-bg.png" />
            <div class="common-wrap">
                <div
                    data-aos="slide-right"
                    class="title md:h-w-full">
                    {{ t('development.socialResponsibility') }}
                </div>
                <div
                    data-aos="slide-up"
                    class="h-flex h-flex-col md:h-flex-row md:h-items-start md:h-rounded-lg h-overflow-hidden">
                    <div class="h-flex h-flex-col h-rounded-lg h-bg-[#FFF] h-px-5 h-py-8 md:h-pb-6 md:h-px-7 md:h-w-[384px] md:h-h-[390px] md:h-rounded-none xl:h-h-[600px] xl:h-px-[60px] xl:h-pt-[100px] xl:h-pb-[60px] xl:h-w-[572px] md:h-order-1">
                        <div :key="realIndex2" data-aos="slide-up" class="h-break-all h-flex h-items-center h-text-base h-font-medium h-text-primary md:h-text-2xl xl:h-text-[28px]">
                            {{ social?.rows[realIndex2]?.title }}
                        </div>
                        <ElScrollbar :key="realIndex2" data-aos="slide-up" class="h-my-10 h-text-sm xl:h-flex-1 xl:h-mb-14 xl:h-text-base h-text-justify">
                            {{ social?.rows[realIndex2]?.subtitle }}
                        </ElScrollbar>
                        <div
                            class="h-mt-auto h-flex"
                            v-if="social?.rows?.length > 1">
                            <div
                                class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary h-mr-3"
                                @click="() => elCarouselRef2?.prev()">
                                <span class="iconfont icon-zuojiantou h-text-primary !h-text-[9px]"></span>
                            </div>
                            <div
                                class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary"
                                @click="() => elCarouselRef2?.next()">
                                <span class="iconfont icon-icon_jiantou h-text-primary !h-text-[9px]"></span>
                            </div>
                        </div>
                    </div>
                    <div class="h-group h-overflow-hidden h-relative h-rounded-md h-w-full h-h-[206px] h-mt-3 md:h-mt-0 md:h-h-[390px] md:h-rounded-none md:h-flex-1 xl:h-h-[600px] md:h-order-2">
                        <el-carousel
                            ref="elCarouselRef2"
                            trigger="click"
                            class="h-h-full"
                            height="100%"
                            indicator-position="none"
                            :autoplay="true"
                            interval="4000"
                            arrow="never">
                            <el-carousel-item
                                v-for="(item, index) in social?.rows"
                                :key="index">
                                <!-- <NuxtImg
                                    class="h-w-full h-h-full h-object-cover"
                                    :src="item.pcImgUrl" /> -->
                                <LottieImage
                                    class="h-w-full h-h-full h-object-cover hover-item-img"
                                    :src="item.pcImgUrl" />
                            </el-carousel-item>
                        </el-carousel>
                    </div>
                </div>
            </div>
        </div>
        <!-- 可持续运营 -->
        <div class="wrap-y-center">
            <div class="common-wrap">
                <div
                    data-aos="slide-right"
                    class="title">
                    {{ t('development.sustainableOperations') }}
                </div>
                <Swiper
                    data-aos="slide-up"
                    effect="flip"
                    :spaceBetween="24"
                    :loop="true"
                    :autoplay="{ delay: 4000 }"
                    :pagination="{
                        clickable: true,
                        el: '.swiper-pagination-two',
                    }"
                    :breakpoints="{
                        320: { slidesPerView: 1 },
                        640: { slidesPerView: 1.5 },
                        768: { slidesPerView: 2 },
                        1024: { slidesPerView: 3 },
                    }"
                    :modules="[Navigation, Autoplay, Pagination]">
                    <SwiperSlide
                        v-for="item in sustainable?.rows"
                        class="h-overflow-hidden h-flex h-flex-col h-justify-between h-border h-border-[#DCDFE6] h-rounded-lg">
                        <!-- <NuxtImg
                            class="h-w-full h-h-[156px] md:h-h-[240px] xl:h-h-[300px] h-object-cover"
                            :src="item.pcImgUrl" /> -->
                        <LottieImage
                            class="h-w-full h-h-[156px] md:h-h-[240px] xl:h-h-[300px] h-object-cover"
                            :src="item.pcImgUrl" />
                        <div class="h-px-[60px] h-py-6 h-text-sm h-text-center md:h-pt-8 md:h-pb-10 md:h-text-base xl:h-text-xl">
                            <div class="h-line-clamp-1">{{ item.title }}</div>
                        </div>
                    </SwiperSlide>
                </Swiper>
                <!-- Swiper 默认样式分页器外置容器 -->
                <div class="swiper-pagination-two h-mt-4 h-text-center"></div>
            </div>
        </div>
        <!-- ESG报告与目标 -->
        <div class="common-wrap wrap-y-bottom !h-pt-0">
            <!-- <div class="title md:h-w-full">{{ t('development.esgReportsAndTargets') }}</div>
            <div class="h-flex h-flex-col h-rounded-xl h-overflow-hidden md:h-flex-row md:h-items-start">
                <div class="h-flex h-flex-col h-bg-[#EEF2F7E5] h-px-5 h-py-8 h-h-80 md:h-pb-6 md:h-px-7 md:h-w-[55%] md:h-h-[360px] xl:h-h-[400px] xl:h-px-[60px] xl:h-pt-[100px] xl:h-pb-[60px]">
                    
                </div>
                <div class="h-flex h-flex-col h-justify-between h-bg-[#F3F4F7] h-py-10 h-px-6 h-h-[226px] md:h-px-20 md:h-py-20 md:h-h-[360px] md:h-flex-1 xl:h-h-[400px] xl:h-py-24">
                    <div class="h-font-medium md:h-text-xl xl:h-text-2xl">2030 年可持续发展目标</div>
                    <div class="">
                        <div v-for="item in egsReport?.rows" class="h-flex h-items-center h-mt-3 h-text-sm md:h-mt-5 xl:h-text-base">
                            <div>➤</div>
                            <div class="h-ml-5">{{ item.title }}</div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="h-mt-5 md:h-mt-8">
                <!-- <div class="title h-font-medium xl:h-text-[28px]">{{ t('development.esgReportsDownload') }}</div> -->
                <div
                    data-aos="slide-right"
                    class="title">
                    {{ t('development.esgReportsDownload') }}
                </div>
                <div
                    data-aos="slide-up"
                    class="h-grid h-grid-cols-1 lg:h-grid-cols-2 xl:h-grid-cols-3 h-gap-y-5 h-gap-x-10">
                    <div
                        v-for="item in fileList?.rows"
                        class="h-group h-flex h-items-center">
                        <span class="iconfont icon-icon_PDF h-text-[#FF5555] !h-text-2xl md:!h-text-[28px] xl:!h-text-[32px]"></span>
                        <div class="h-ml-2 h-flex-1 h-mr-5 h-text-sm md:h-text-base h-line-clamp-1 h-text-secondary group-hover:!h-text-main">{{ item.title }}</div>
                        <button
                            class="file-btn h-text-xs !h-box-content !h-leading-none h-py-[7px] h-px-[18px] h-border h-rounded h-text-primary hover:h-bg-[#E6F1FF] active:h-border-primary"
                            @click="openDownload(item.fileUrl)">
                            {{ t('common.view') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { definePageMeta, useDevelopmentStore } from '#imports'
import InformationService from '~/service/information'
import ImgService from '~/service/img'
import DocumentService from '~/service/document'
import { computed } from 'vue'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Autoplay, Pagination, Navigation } from 'swiper/modules'
import 'swiper/css'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
import { ElScrollbar } from 'element-plus'
definePageMeta({
    layout: 'development-layout',
})
const { t } = useI18n()

const { paddingLeft: left } = useScreen()

const paddingLeft = computed(() => left.value)

const elCarouselRef1 = ref()
const elCarouselRef2 = ref()
const realIndex1 = computed(() => {
    const index = elCarouselRef1.value?.activeIndex ?? 0
    const length = green.value.rows.length
    return index % length
})
const realIndex2 = computed(() => {
    const index = elCarouselRef2.value?.activeIndex ?? 0
    const length = social.value.rows.length
    return index % length
})

// 顶部图片
const developmentStore = useDevelopmentStore()
const { queryDevelopmentBannerList } = developmentStore
queryDevelopmentBannerList()

// 环境保护
const { data: envList } = await ImgService.queryImgList({
    locationCodes: 'uScxDcMu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('环境保护数据 :>> ', envList.value?.rows)

// 绿色技术创新
const { data: green } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uSkcAcMu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('绿色技术创新信息 :>> ', green.value?.rows)

// 社会责任
const { data: social } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uSkxBcMu',
    pageNum: 1,
    pageSize: 6,
    status: 1,
    websiteCode: '3',
})
// console.error('社会责任信息 :>> ', social.value?.rows)

// 可持续运营
const { data: sustainable } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uScxaaCu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('可持续运营 :>> ', sustainable.value?.rows)

// ESG报告与目标
const { data: egsReport } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uScxbbCu',
    pageNum: 1,
    pageSize: 5,
    status: 1,
    websiteCode: '3',
})
// console.error('ESG报告与目标 :>> ', egsReport.value?.rows)

// ESG报告文件
const { data: fileList } = await DocumentService.queryDocumentList({
    keyword: '',
    locationCodes: 'uSkcxeMu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('文件数据 :>> ', fileList.value?.rows)

const openDownload = url => {
    window.open(url, '_blank')
}
</script>

<style scoped>
.development-page {
    .file-btn:hover ~ {
    }
}
</style>
