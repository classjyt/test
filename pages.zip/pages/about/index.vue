<template>
    <div class="about-page">
        <SubHeader
            :title="'关于我们'"
            :navList="navList"
            :bannerList="bannerList" />
        <NuxtPage />
    </div>
</template>

<script setup>
import { NuxtPage } from '#components'
import { definePageMeta } from '#imports'
import { defineNuxtComponent, navigateTo } from 'nuxt/app'
import ImgService from '~/service/img'

const bannerList = ref([])
const queryAboutBannerList = async () => {
    const params = {
        keyword: '',
        locationCodes: 'uapiuFhT',
        pageNum: 1,
        pageSize: 200,
        status: 1,
    }
    const { data } = await ImgService.queryImgList(params, {
        headers: { 'Cache-Control': 'public, max-age=300' }, // 5分钟缓存
    })
    bannerList.value = data
}

// 服务端预获取（SSR 优化）
onServerPrefetch(async () => {
    await queryAboutBannerList()
})

// 客户端获取（如果是客户端导航）
if (process.client) {
    // 避免在重定向后重复请求
    const route = useRoute()
    if (!route.redirectedFrom) {
        queryAboutBannerList()
    }
}

// 设置页面元信息
definePageMeta({
    layout: 'default',
    // 如果需要默认重定向到company页面

    validate: ({ params }) => {
        const supportedLangs = ['zh', 'en']
        if (params.lang && !supportedLangs.includes(params.lang)) {
            throw createError({
                statusCode: 404,
                message: `Language '${params.lang}' not supported`,
                data: {
                    supportedLanguages: supportedLangs,
                    // documentation: 'https://yourdomain.com/docs/languages',
                },
            })
        }
        return true
    },

    middleware: [
        ({ path, redirect }) => {
            if (path === '/about' || path.startsWith('/zh/about') || path.startsWith('/en/about')) {
                // 获取当前语言（zh 或 en），默认 'zh'
                const lang = path.startsWith('/en/') ? 'en' : 'zh'
                return redirect(`/${lang}/about/company`)
            }
        },
    ],

    // middleware: [
    //     async to => {
    //         const router = useRouter()
    //         const currentRoute = useRoute()

    //         // 防止重定向循环
    //         if (currentRoute.redirectedFrom) return

    //         // 获取用户首选语言
    //         const getPreferredLang = () => {
    //             // 实现同上...
    //         }

    //         // 重定向逻辑
    //         const shouldRedirect = () => {
    //             const path = to.path
    //             const lang = getPreferredLang()

    //             // 重定向规则
    //             const rules = {
    //                 '/about': `/${lang}/about/company`,
    //                 '/zh/about': '/zh/about/company',
    //                 '/en/about': '/en/about/company',
    //                 '/ja/about': '/ja/about/company',
    //                 '/about-us': `/${lang}/about/company`,
    //                 '/company-info': `/${lang}/about/company`,
    //             }

    //             return rules[path] || (path.startsWith('/about/') && !to.params.lang ? `/${lang}${path.replace('/about', '/about')}` : null)
    //         }

    //         const redirectPath = shouldRedirect()
    //         if (redirectPath) {
    //             return navigateTo(redirectPath, {
    //                 redirectCode: redirectPath === to.path ? 308 : 301,
    //                 replace: true,
    //                 external: false,
    //             })
    //         }
    //     },
    // ],
})
</script>
