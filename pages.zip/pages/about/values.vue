<template>
    <div class="values-wrap h-w-full">
        <div
            data-aos="slide-up"
            data-aos-easing="cubic-bezier(0.1, 1, 1, 0.25)"
            class="common-wrap wrap-y-top xl:h-pt-20 h-relative h-flex h-flex-col md:h-flex-row">
            <div class="h-flex h-flex-col h-px-4 h-py-6 h-bg-[#EEF2F7E5] h-rounded-lg md:h-absolute md:h-top-[120px] md:h-p-10 md:h-text-[28px] md:h-rounded-[20px] xl:h-top-[160px] xl:h-py-[60px] h-transition-all"
                :class="locale === 'zh' ? 'xl:h-text-4xl' : 'xl:h-text-3xl'"
            >
                <div class="h-text-primary">{{ t('about.missionAndVision') }}</div>
                <div class="h-relative h-mt-6 h-w-full h-h-[1px] h-bg-[#00409866] md:h-mt-5 xl:h-mt-10">
                    <div class="h-absolute h-z-10 h-left-0 -h-top-[1.5px] h-w-20 h-h-1 h-bg-primary"></div>
                </div>
            </div>
            <div class="h-overflow-hidden h-relative h-mt-4 h-flex h-flex-col h-justify-center h-items-start h-px-6 h-py-[60px] h-text-white h-rounded-lg md:h-mt-0 md:h-ml-36 md:h-pl-[160px] h-w-full xl:h-ml-[180px] xl:h-pl-[200px] h-text-xl md:h-text-2xl xl:h-text-[28px] md:h-h-[320px] xl:h-h-[400px]">
                <NuxtImg class="h-absolute -h-z-10 h-top-0 h-left-0 h-w-full h-h-full h-object-cover h-bg-center" :src="hope.pcImgUrl" />
                <!-- <LottieImage
                    class="h-absolute -h-z-10 h-top-0 h-left-0 h-w-full h-h-full h-object-cover h-bg-center"
                    :src="hope.pcImgUrl" /> -->
                <div data-aos="fade-up" data-aos-delay="300" class="h-text-xl md:h-text-2xl md:h-inline-block">
                    <div class="h-font-bold">{{ hope.title }}</div>
                </div>
                <div data-aos="fade-up" data-aos-delay="1000" class="h-w-auto">
                    <div class="h-relative h-my-5 h-h-[1px] h-bg-white md:h-my-7">
                        <div class="h-absolute h-z-10 h-left-0 -h-top-[1.5px] h-w-20 h-h-1 h-bg-white md:h-w-[120px]"></div>
                    </div>
                    <div class="md:h-text-2xl h-text-justify">{{ hope.subtitle }}</div>
                </div>
            </div>
        </div>
        
        <div class="h-w-full h-relative wrap-y-center md:h-py-20 xl:h-py-[100px]">
            <NuxtImg class="h-absolute h-top-0 h-left-0 -h-z-10 h-h-full h-w-full h-bg-center h-object-cover" src="/images/social/responsibility-bg.png" />
            <div
                class='common-wrap'>
                <div data-aos='slide-right' class='title'>{{ t('about.coreValues') }}</div>
                <div class="wrap-scroll-x-auto h-gap-5 md:h-gap-7 xl:h-gap-10 h-grid h-grid-cols-1 md:h-grid-cols-2" >
                    <div v-for="item in mainValuesList" class='h-flex h-flex-col xl:h-flex-row h-rounded-lg h-overflow-hidden h-bg-white h-p-5 md:h-py-7 xl:h-px-10 xl:h-py-10'>
                        <!-- <NuxtImg data-aos='zoom-in' class='h-rounded-lg h-object-cover h-w-full h-h-40 md:h-h-[220px] xl:h-w-80 xl:h-h-[220px] h-bg-center' :src="item.pcImgUrl"></NuxtImg> -->
                        <LottieImage
                            data-aos='zoom-in'
                            class='h-rounded-lg h-object-cover h-w-full h-h-40 md:h-h-[220px] xl:h-w-80 xl:h-h-[220px] h-bg-center'
                            :src="item.pcImgUrl" />
                        <div data-aos='slide-up' data-aos-easing="cubic-bezier(0.1, 1, 1, 0.25)" class='h-w-full xl:h-flex xl:h-flex-col h-mt-5 md:h-mt-7 xl:h-mt-0 xl:h-ml-10'>
                            <div class="h-flex h-font-medium h-leading-7 md:h-text-xl xl:h-text-2xl">
                                <div class="h-line-clamp-2">{{ item.title }}</div>
                            </div>
                            <div class="h-mt-4 h-text-sm h-leading-[22px] md:h-mt-6 xl:h-mt-7 xl:h-leading-7 h-text-justify">{{ item.subtitle }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="common-wrap wrap-y-bottom">
            <div data-aos='slide-right' class='title'>{{ t('about.slogan') }}</div>
            <div  class="h-overflow-hidden h-rounded-lg h-flex h-flex-col h-mt-3 md:h-mt-5 md:h-flex-row md:h-h-[340px] xl:h-h-[520px] h-relative">
                <!-- <NuxtImg data-aos='zoom-out' class="h-object-cover h-bg-center h-w-full h-h-40 md:h-h-full" :src="detail3.pcImgUrl" fit="inside" /> -->
                <LottieImage
                    data-aos='zoom-out'
                    data-aos-duration="2000"
                    class="h-object-cover h-bg-center h-w-full h-h-40 md:h-h-full"
                    :src="detail3.pcImgUrl"
                    fit="inside" />
                <!-- <div class="h-flex h-flex-col h-py-3 h-bg-[#F3F4F7] h-text-center md:h-absolute h-w-full md:h-bg-transparent md:h-text-white md:h-pt-10 md:h-h-1/2 md:h-bg-[linear-gradient(180deg,rgba(10,34,64,0.5)_11%,rgba(10,34,64,0)_99%)] h-transition-all">
                    <div data-aos='slide-up' data-aos-delay='50' class="opacity-0 md:h-text-2xl xl:h-text-4xl">{{ detail3.title }}</div>
                    <div data-aos='slide-up' data-aos-delay='150' class="opacity-0 h-mt-2 h-text-xs md:h-mt-2 xl:h-mt-4 md:h-text-base md:h-leading-8 xl:h-text-2xl">{{ detail3.subtitle }}</div>
                </div> -->
            </div>
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'about-layout',
})

const { $i18n } = useNuxtApp()
const locale = $i18n.locale.value

import ImgService from '~/service/img';
const { t } = useI18n()

const aboutStore = useAboutStore()
const { queryAboutBannerList } = aboutStore
queryAboutBannerList()

const { paddingLeft: left } = useScreen()

const paddingLeft = computed(() => left.value)

// 使命与愿景数据
const hope = ref()
const params = {
    keyword: '',
    locationCodes: 'WyrwuFhT',
    pageNum: 1,
    pageSize: 1,
    status: 1,
    websiteCode: '3',
}
const response = await ImgService.queryImgList(params)
hope.value = response.data.value?.rows?.[0] || {}
// console.error('使命与愿景信息 :>> ', response.data.value?.rows?.[0]);

// 核心价值数据
const mainValuesList = ref([])
const response2 = await ImgService.queryImgList({
    keyword: '',
    locationCodes: '2ssOuFhT',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
mainValuesList.value = response2.data.value?.rows.filter((item, index) => index < 2) || []
// console.error('核心价值信息 :>> ', response2.data.value?.rows);

// 口号数据
const detail3 = ref([])
const response3 = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uodw9PsT',
    pageNum: 1,
    pageSize: 1,
    status: 1,
    websiteCode: '3',
})
detail3.value = response3.data.value?.rows?.[0] || {}
// console.error('口号信息 :>> ', response3.data.value?.rows?.[0]);

</script>

<style scoped>
.values-wrap {
}
</style>
