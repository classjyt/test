<template>
    <div class="company-wrap">
        <!-- 公司简介 -->
        <div class="h-w-full">
            <div class="common-wrap wrap-y-top xl:h-pt-20 h-flex h-flex-col xl:h-flex-row md:h-items-start h-flex-wrap">
                <div data-aos="slide-right" class="title xl:h-w-full">{{ t('about.companyProfile') }}</div>
                <div data-aos="slide-up" class="h-overflow-hidden h-flex h-flex-col h-w-full h-justify-between h-rounded-lg h-bg-[#EEF2F7] h-bg-opacity-90 h-px-5 h-py-8 xl:h-py-[100px] h-h-50 md:h-px-10 xl:h-h-[600px] xl:h-rounded-tr-none xl:h-rounded-br-none xl:h-px-[60px] xl:h-w-[572px]">
                    <div>
                        <div class="h-flex h-items-center h-text-base h-text-primary md:h-text-[28px] md:h-leading-8">
                            <div class="h-font-medium">恒力重工</div>
                            <div class="h-ml-1.5">向海 向未来</div>
                        </div>
                        <div class="h-mt-2 h-text-sm md:h-text-xl md:h-leading-8 xl:h-mt-3">FACING THE SEA TOWARDS THE FUTURE</div>
                    </div>
                    <ElScrollbar class="h-w-full h-text-sm h-mt-10 md:h-text-base md:h-leading-7">
                        <pre class="h-whitespace-pre-wrap h-text-justify">{{ companyIntro.subtitle }}</pre>
                    </ElScrollbar>
                </div>
                <div data-aos="slide-up" class="h-overflow-hidden h-relative h-rounded-md h-mt-3 h-w-full h-h-[206px] md:h-h-[360px] xl:h-rounded-lg xl:h-rounded-tl-none xl:h-rounded-bl-none xl:h-flex-1 md:h-mt-4 xl:h-h-[600px] xl:h-mt-0">
                    <!-- <NuxtImg
                        class="h-w-full h-h-full h-object-cover h-bg-center"
                        :src="companyIntro.pcImgUrl" /> -->
                    <LottieImage
                        class="h-w-full h-h-full h-object-cover h-bg-center"
                        :src="companyIntro.pcImgUrl" />
                    <div
                        class="h-absolute h-z-10 h-w-full h-right-0 h-bottom-0 h-flex h-justify-end h-items-center h-px-4 h-py-[14px] h-bg-black h-bg-opacity-15 h-text-white h-text-sm h-text-right h-backdrop-blur-sm 
                        md:h-py-6 md:h-px-5 md:h-text-xl md:h-leading-8 
                        xl:h-py-8 xl:h-px-10 xl:h-text-xl 
                        "
                        v-html="companyIntro.title"></div>
                </div>
            </div>
        </div>
        <!-- 公司现状 -->
        <div
            class="wrap-y-center xl:h-py-[100px] h-w-full h-bg-center h-bg-cover h-bg-no-repeat"
            :style="{
                backgroundImage: `url('/images/about/company-info-bg.webp')`,
            }">
            <div class="h-relative common-wrap">
                <div data-aos='slide-right' class="title h-text-white">{{ t('about.companyStatus') }}</div>
                <!-- <Swiper
                    data-aos='slide-up'
                    :effect="'coverflow'"
                    :grabCursor="true"
                    :centeredSlides="true"
                    :slidesPerView="'auto'"
                    :loop="true"
                    :autoplay="{ delay: 2000 }"
                    :coverflowEffect="{
                        rotate: 50,
                        stretch: 0,
                        depth: 100,
                        modifier: 1,
                        slideShadows: true,
                    }"
                    :pagination="true"
                    :modules="[EffectCoverflow, Autoplay, Navigation]"
                    class="mySwiper h-relative h-w-full !h-m-0 lg:h-h-[300px]">
                    <SwiperSlide
                        v-for="(item, index) in situationList"
                        class="h-overflow-hidden h-px-3 !h-w-[400px] !h-h-[300px] !h-flex h-flex-col h-justify-between h-bg-[#FFFFFFCC] h-backdrop-blur-sm h-border-white h-rounded-lg h-py-[60px] h-transition-all h-duration-500"
                        :key="index">
                        <div class="h-flex h-justify-center">
                            <NuxtImg
                                class="h-w-12 h-h-12 h-object-cover h-bg-center"
                                :src="item.pcImgUrl" />
                        </div>
                        <div class="h-flex h-flex-col h-justify-center h-items-center h-mt-auto">
                            <div
                                class="count h-flex h-justify-center h-text-xl md:h-text-2xl xl:h-text-[28px]"
                                style="font-family: 'PangMenZhengDao'">
                                <CountUp
                                    v-if="!isNaN(item.subtitle)"
                                    class="h-line-clamp-1 h-break-all"
                                    :end="Number(item.subtitle)"
                                    duration="0.5" />
                                <div v-else>
                                    {{ item.subtitle }}
                                </div>
                            </div>
                            <div class="h-mt-5 h-text-center h-line-clamp-1">{{ item.title }}</div>
                        </div>
                    </SwiperSlide>
                </Swiper> -->
                <Swiper
                    data-aos='slide-up'
                    :modules="[Autoplay, Navigation, Pagination]"
                    :slidesPerView="1.1"
                    :loop="true"
                    :autoplay="{ delay: 2000 }"
                    effect="flip"
                    :space-between="32"
                    :breakpoints="{
                        320: { slidesPerView: 1.5 },
                        640: { slidesPerView: 2.2 },
                        768: { slidesPerView: 2.5 },
                        1024: { slidesPerView: 3 },
                        1280: { slidesPerView: 4 },
                    }"
                    @swiper="onSwiper"
                    class="mySwiper h-pt-5 h-relative h-w-full !h-m-0 lg:h-h-[380px]">
                    <SwiperSlide
                        v-for="(item, index) in situationList"
                        class="h-overflow-hidden h-px-3 !h-h-[300px] !h-flex h-flex-col h-justify-between h-bg-[#FFFFFFCF] h-backdrop-blur-sm h-border-white h-rounded-lg h-py-[60px] h-transition-all h-duration-500"
                        :key="index">
                        <div class="h-flex h-justify-center">
                            <NuxtImg
                                class="h-w-12 h-h-12 h-object-cover h-bg-center"
                                :src="item.pcImgUrl" />
                        </div>
                        <div class="h-flex h-flex-col h-justify-center h-items-center h-mt-auto">
                            <div
                                class="count h-w-full h-flex h-justify-center h-text-xl md:h-text-2xl xl:h-text-[28px]"
                                style="font-family: 'PangMenZhengDao'">
                                <CountUp
                                    v-if="!isNaN(item.subtitle)"
                                    class="h-line-clamp-1 h-break-all"
                                    :end="Number(item.subtitle)"
                                    duration="0.5" />
                                <div v-else>
                                    {{ item.subtitle }}
                                </div>
                            </div>
                            <div class="h-mt-5 h-text-center h-line-clamp-1">{{ item.title }}</div>
                        </div>
                    </SwiperSlide>
                    <div class="lg:h-absolute h-bottom-0 md:h-left-[calc((100%-64px)/2.5+32px)] lg:h-left-[calc((100%-64px)/3+32px)] xl:h-left-[calc((100%-96px)/4+32px)] h-flex h-z-40">
                        <div
                            class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary h-mr-3"
                            @click="() => goPrev()">
                            <span class="iconfont icon-zuojiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                        <div
                            class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary"
                            @click="() => goNext()">
                            <span class="iconfont icon-icon_jiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                    </div>
                </Swiper>
            </div>
        </div>
        <!-- 公司地址 -->
        <div class="h-w-full">
            <div class="common-wrap h-overflow-hidden h-py-8 md:h-py-20 xl:h-pt-[220px] xl:h-pb-[185px]">
                <div class="xl:h-relative h-flex h-flex-col md:h-flex-row md:h-items-start md:h-flex-wrap">
                    <div
                        data-aos='slide-right'
                        data-aos-offset='0'
                        class="h-relative h-transition-all h-z-[40] h-flex h-flex-col h-rounded-lg h-bg-primary h-text-white h-px-5 h-py-8 md:h-px-7 md:h-py-[100px] md:h-w-[360px] md:h-h-[360px] md:h-rounded-tr-none md:h-rounded-br-none md:h-text-sm xl:h-absolute xl:h-left-0 xl:-h-top-[60px] xl:h-px-[50px] xl:h-h-[400px] xl:h-w-[440px] xl:h-rounded-lg h-bg-opacity-90 h-backdrop-blur-[6px] h-bg-center h-bg-cover h-bg-no-repeat"
                        style="background-image: url('/images/about/address-bg.png')"
                    >
                        <div class="h-flex h-items-center h-mb-10 h-text-sm md:h-mb-auto md:h-text-xl">
                            <!-- <NuxtImg
                                width="auto"
                                height="30"
                                src="/images/contact/logo.png"
                                class="h-object-contain" /> -->
                            <NuxtImg
                                width="250px"
                                src="/images/logo.svg"
                                class="h-object-contain" />
                        </div>
                        <div class="h-mt-auto h-leading-[26px]">
                            <div class="h-break-all">{{ t('common.address') }}：{{ companyInfo.companyAddr }}</div>
                            <div>{{ t('common.phone') }}：{{ companyInfo.telephoneNumber }}</div>
                            <!-- <div>{{ t('common.fax') }}：{{ companyInfo.faxNumber }}</div> -->
                        </div>
                    </div>
                    <div data-aos='slide-left' data-aos-offset='-60' class="md:h-flex-1 h-mt-3 md:h-mt-0 h-h-52 md:h-h-[360px] xl:h-pl-[360px] xl:h-h-[480px]">
                        <TencentMap class="h-w-full h-h-full h-rounded-md md:h-rounded-lg md:h-rounded-tl-none md:h-rounded-bl-none xl:h-rounded-lg"></TencentMap>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup>
import 'swiper/css'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Autoplay, Pagination, Navigation, EffectCoverflow } from 'swiper/modules'

definePageMeta({
    layout: 'about-layout',
    // 设置别名，使/about和/about/company都能访问
    alias: ['/about'],
})

import { NuxtImg } from '#components'
import { definePageMeta, useFooterStore, useAboutStore } from '#imports'
import { onMounted } from 'vue'
import ImgService from '~/service/img'
const { $i18n } = useNuxtApp()
const locale = $i18n.locale.value

const { t } = useI18n()
const footerStore = useFooterStore()
const { companyInfo } = footerStore

const currentIndex = ref(0)

const aboutStore = useAboutStore()
const { queryAboutBannerList } = aboutStore
queryAboutBannerList()

const companyIntro = ref()
const params = {
    keyword: '',
    locationCodes: 'uodwuFhT',
    pageNum: 1,
    pageSize: 1,
    status: 1,
    websiteCode: '3',
}
const response = await ImgService.queryImgList(params)
companyIntro.value = response.data.value?.rows?.[0] || {}
// console.error('公司简介信息 :>> ', response.data.value?.rows?.[0])

const situationList = ref([])
const params2 = {
    keyword: '',
    locationCodes: 'loaOFrdt',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
}
const response2 = await ImgService.queryImgList(params2)
situationList.value = response2.data.value?.rows || {}
// console.error('公司现状信息 :>> ', response2.data.value?.rows)

// 存储 Swiper 实例
const swiperRef = ref()
const onSwiper = swiperInstance => {
    swiperRef.value = swiperInstance
}

const goPrev = () => {
    swiperRef.value?.slidePrev()
}
const goNext = () => {
    swiperRef.value?.slideNext()
}
</script>

<style scoped>
.mySwiper {
    box-sizing: content-box;
}

.swiper-slide-active {
    @apply lg:!h-h-[380px] h-transition-all h-border-2;

    .count {
        @apply h-text-2xl md:h-text-3xl xl:h-text-[40px];
    }
}
</style>
