<template>
    <div class="contact-page h-w-full">
        <div class="common-wrap h-mt-20 h-font-bold h-text-[32px] h-text-[#303133] h-flex h-justify-center">下载恒力CIMS客户端</div>
        <div class="common-wrap h-mt-10 h-font-medium h-text-[24px] h-text-[#606266] h-flex h-justify-center">支持Windows、macOS、iOS、Android版本</div>
        <div class="common-wrap h-mt-20 h-flex h-items-center h-justify-between h-w-[810px]">
            <div class="h-w-[180px] h-h-[180px] h-border h-border-b-1 h-border-[#DCDFE6] border-radius-20">
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] top-img"
                    src="/images/contact/icon_qrcode.png"
                />
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] top-mian"
                    src="/images/contact/icon_ios.png"
                />
                <div class="h-text-[20px] h-text-[#303133] text-main">ios</div>

                <NuxtImg
                    class="h-w-[90px] h-h-[90px] hover-top-mian"
                    src="/images/contact/cimsApp.png"
                />
                <div class="h-text-[20px] h-text-[#303133] hover-text-main">ios</div>
                <div class="h-text-[14px] h-text-[#909399] hover-text-remark">扫码下载</div>
            </div>
            <div class="h-w-[180px] h-h-[180px] h-border h-border-b-1 h-border-[#DCDFE6] border-radius-20">
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] top-img"
                    src="/images/contact/icon_qrcode.png"
                />
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] top-mian"
                    src="/images/contact/icon_android.png"
                />
                <div class="h-text-[20px] h-text-[#303133] text-main">Android</div>

                <NuxtImg
                    class="h-w-[90px] h-h-[90px] hover-top-mian"
                    src="/images/contact/cimsApp.png"
                />
                <div class="h-text-[20px] h-text-[#303133] hover-text-main">Android</div>
                <div class="h-text-[14px] h-text-[#909399] hover-text-remark">扫码下载</div>
            </div>
            <div class="h-w-[180px] h-h-[180px] h-border h-border-b-1 h-border-[#DCDFE6] border-radius-20" @click="download('mac')">
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] macOs-img"
                    src="/images/contact/icon_macOS.png"
                />
                <div class="h-text-[20px] h-text-[#303133] text-macOs">macOS</div>
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] hover-macOs-img"
                    src="/images/contact/icon_down.png"
                />
                <div class="h-text-[20px] h-text-[#303133] hover-text-macOs">macOS</div>
                <div class="h-text-[14px] h-text-[#909399] hover-macOs-remark">点击下载</div>
            </div>
            <div class="h-w-[180px] h-h-[180px] h-border h-border-b-1 h-border-[#DCDFE6] border-radius-20" @click="download('windows')">
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] macOs-img"
                    src="/images/contact/icon_windows.png"
                />
                <div class="h-text-[20px] h-text-[#303133] text-macOs">Windows</div>
                <NuxtImg
                    class="h-w-[60px] h-h-[60px] hover-macOs-img"
                    src="/images/contact/icon_down.png"
                />
                <div class="h-text-[20px] h-text-[#303133] hover-text-macOs">Windows</div>
                <div class="h-text-[14px] h-text-[#909399] hover-macOs-remark">点击下载</div>
            </div>
        </div>
        <div class="mian-bottom-div h-mt-20 h-mb-20 h-flex h-justify-center">
            <NuxtImg
                class="h-w-[762px] h-h-[370px]"
                src="/images/contact/icon_pc_img.png"
            />
        </div>
    </div>
</template>

<script setup>
    definePageMeta({
        layout: 'download-layout',
    })
    const { t } = useI18n()
    const footerStore = useFooterStore()
    const { companyInfo } = footerStore

    // 顶部图片
    const downloadStore = useDownloadStore()
    const { queryDownloadBannerList } = downloadStore
    queryDownloadBannerList()

    onMounted(() => {
    })

    const download = (computerType) => {
        downloadClient(computerType)
    }


</script>

<style scoped>
.contact-page {
    @media (min-width: theme('screens.md')) {
        .detail-item {
            @apply h-mt-2;
        }
    }
    .border-radius-20{
        border-radius: 20px;
        cursor: pointer;
        text-align: center;

        .top-img{
            position: relative;
            left: 120px;
            display: block;
        }
        .top-mian{
            position: relative;
            left: 60px;
            top: -20px;
            display: block;
        }
        .text-main{
            position: relative;
            top: -10px;
            display: block;
        }
        .hover-top-mian{
            display: none;
        }
        .hover-text-main{
            display: none;
        }
        .hover-text-remark{
            display: none;
        }
        .macOs-img{
            position: relative;
            left: 60px;
            top: 40px;
        }
        .text-macOs{
            position: relative;
            top: 50px;
        }
        .hover-macOs-img{
            display: none;
        }
        .hover-text-macOs{
            display: none;
        }
        .hover-macOs-remark{
            display: none;
        }
    }
    .border-radius-20:hover{
        .top-img{
            display: none;
        }
        .top-mian{
           display: none;
        }
        .text-main{
            display: none;
        }

        .hover-top-mian{
            position: relative;
            top: 20px;
            left: 45px;
            display: block;
        }
        .hover-text-main{
            position: relative;
            top: 20px;
            display: block;
        }
        .hover-text-remark{
            position: relative;
            top: 20px;
            display: block;
        }
        .macOs-img{
            display: none;
        }
        .text-macOs{
            display: none;
        }
        .hover-macOs-img{
            display: block;
            position: relative;
            left: 60px;
            top: 40px;
        }
        .hover-text-macOs{
            display: block;
            position: relative;
            top: 50px;
        }
        .hover-macOs-remark{
            display: block;
            position: relative;
            top: 50px;
        }
    }
    .mian-bottom-div{
        width: 100%;
        text-align: center;
        /* margin: 20px auto; */
    }
}
</style>
