<template>
    <div class="outcomes-wrap h-w-full">
        <div class="common-wrap wrap-y-all h-pb-14">
            <div class="h-group h-cursor-pointer h-flex h-flex-col md:h-flex-row md:h-items-start md:h-rounded-lg h-overflow-hidden"
                @click="() => toDetail(first)"
            >
                <div class="h-flex h-flex-col h-rounded-lg h-border-2 h-border-white h-px-5 h-py-8 h-bg-[#F3F4F7] md:h-px-7 md:h-w-2/5 md:h-h-[360px] md:h-border-none md:h-rounded-none xl:h-h-[480px] xl:h-px-[60px] xl:h-py-[60px] md:h-order-2">
                    <div class="hover-item-title h-text-base h-font-semibold md:h-text-xl xl:h-text-2xl h-line-clamp-1 h-shrink-0">{{ first?.title }}</div>
                    <ElScrollbar class="h-my-5 h-text-sm md:h-mt-6 md:h-text-base md:h-leading-7 h-text-justify">
                        {{ first?.excerpt }}
                    </ElScrollbar>
                    <div class="h-mt-auto">
                        <div class='h-inline-flex h-items-center h-cursor-pointer'>
                            <div class='h-flex h-justify-center h-items-center h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-bg-white h-bg-opacity-60 group-hover:h-bg-opacity-100 group-active:h-border-primary h-mr-1.5 md:h-mr-3'>
                                <span class="iconfont icon-icon_jiantou h-text-primary !h-text-[9px]"></span>
                            </div>
                            <span class='h-text-sm group-hover:h-font-semibold'>了解更多</span>
                        </div>
                    </div>
                </div>
                <div data-aos="zoom-out" class="hover-item-img h-overflow-hidden h-w-full h-mt-3 h-h-full h-object-cover h-rounded-lg md:h-rounded-none md:h-mt-0 md:h-w-3/5 md:h-h-[360px] md:h-order-1 xl:h-h-[480px]">
                    <!-- <NuxtImg
                        class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                        :src="first.coverUrl || '/images/placeholder.png'" /> -->
                    <LottieImage
                        class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                        :src="first.coverUrl" />
                </div>
            </div>
        </div>
        <div class="common-wrap wrap-y-bottom !h-pt-0 h-grid h-grid-cols-2 md:h-grid-cols-2 h-gap-3 md:h-gap-5 xl:h-grid-cols-3 xl:h-gap-7">
            <div v-for="item in other" class="h-group h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer" @click="() => toDetail(item)">
                <div data-aos="zoom-out" class="h-w-full h-mt-3 h-h-full md:h-mt-0 md:h-h-[215px] xl:h-h-[215px]">
                    <!-- <NuxtImg
                        class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                        :src="item.coverUrl || '/images/placeholder.png'" /> -->
                    <LottieImage
                        class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                        :src="first.coverUrl" />
                </div>
                <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                    <div class="hover-item-title h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ item?.title }}</div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import InformationService from '~/service/information'
definePageMeta({
    layout: 'party-building-layout',
})

import { storeToRefs, usePartyBuildingStore } from '#imports'
import { ElScrollbar } from 'element-plus';
const partyBuildingStore = usePartyBuildingStore()
const { queryPartyBuildingBannerList } = partyBuildingStore
queryPartyBuildingBannerList()

const { data: list1 } = await InformationService.outQueryInformationList({
    locationCodes: 'XSDTCVwu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('党建活动与成果数据 :>> ', list1.value?.rows)
const first = computed(() => list1.value?.rows[0])
const other = computed(() => list1.value?.rows?.filter((v, i) => i > 0))

const toDetail = (item) => {
    navigateTo({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode: 'XSDTCVwu',
        },
    })
}
</script>

<style scoped>
.outcomes-wrap {
}
</style>
