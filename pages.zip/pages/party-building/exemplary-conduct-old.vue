<template>
    <div class="exemplary-conduct-wrap h-w-full">
        <div class="common-wrap wrap-y-all">
            <div data-aos="slide-right" class="title">党员先锋</div>
            <ElCarousel
                trigger="hover"
                height="265px"
                class="h-hidden h-relative !h-h-[298px] xl:h-block"
                :arrow="never"
                indicator-position="outside">
                <ElCarouselItem
                    v-for="(item, index) in list1PC"
                    :key="index">
                    <div class="h-grid h-grid-cols-2 xl:h-grid-cols-3 h-gap-4 md:h-gap-5 xl:h-gap-7">
                        <div
                            v-for="(v, i) in item"
                            class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                            @click="() => toDetail(v, 'loaOGrdt')">
                            <div data-aos="zoom-out" class="h-w-full h-h-[215px] h-overflow-hidden">
                                <!-- <NuxtImg
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" /> -->
                                <LottieImage
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" />
                            </div>
                            <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                                <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v?.title }}</div>
                            </div>
                        </div>
                    </div>
                </ElCarouselItem>
            </ElCarousel>
            <div class="xl:h-hidden h-grid h-grid-cols-2 h-gap-4 md:h-gap-5 xl:h-gap-7">
                <div
                    v-for="(v, i) in list1?.rows"
                    class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                    @click="() => toDetail(v, 'loaOGrdt')">
                    <div data-aos="zoom-out" class="h-overflow-hidden h-w-full h-h-[94px] md:h-h-[215px]">
                        <!-- <NuxtImg
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" /> -->
                        <LottieImage
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" />
                    </div>
                    <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                        <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v.title }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-wrap wrap-y-all !h-pt-0">
            <div data-aos="slide-right" class="title">党员模范</div>
            <ElCarousel
                trigger="hover"
                height="265px"
                class="h-hidden h-relative !h-h-[298px] xl:h-block"
                :arrow="never"
                indicator-position="outside">
                <ElCarouselItem
                    v-for="(item, index) in list2PC"
                    :key="index">
                    <div class="h-grid h-grid-cols-2 xl:h-grid-cols-3 h-gap-4 md:h-gap-5 xl:h-gap-7">
                        <div
                            v-for="(v, i) in item"
                            class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                            @click="() => toDetail(v, 'uSaucIqu')">
                            <div data-aos="zoom-out" class="h-w-full h-h-[215px] h-overflow-hidden">
                                <!-- <NuxtImg
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" /> -->
                                <LottieImage
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" />
                            </div>
                            <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                                <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v?.title }}</div>
                            </div>
                        </div>
                    </div>
                </ElCarouselItem>
            </ElCarousel>
            <div class="xl:h-hidden h-grid h-grid-cols-2 h-gap-4 md:h-gap-5 xl:h-gap-7">
                <div
                    v-for="(v, i) in list2?.rows"
                    class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                    @click="() => toDetail(v, 'uSaucIqu')">
                    <div data-aos="zoom-out" class="h-overflow-hidden h-w-full h-h-[94px] md:h-h-[215px]">
                        <!-- <NuxtImg
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" /> -->
                        <LottieImage
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" />
                    </div>
                    <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                        <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v.title }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-wrap wrap-y-all !h-pt-0">
            <div data-aos="slide-right" class="title">优秀党员</div>
            <ElCarousel
                trigger="hover"
                height="265px"
                class="h-hidden h-relative !h-h-[298px] xl:h-block"
                :arrow="never"
                indicator-position="outside">
                <ElCarouselItem
                    v-for="(item, index) in list3PC"
                    :key="index">
                    <div class="h-grid h-grid-cols-2 xl:h-grid-cols-3 h-gap-4 md:h-gap-5 xl:h-gap-7">
                        <div
                            v-for="(v, i) in item"
                            class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                            @click="() => toDetail(v, 'uSauWhqu')">
                            <div data-aos="zoom-out" class="h-w-full h-h-[215px] h-overflow-hidden">
                                <!-- <NuxtImg
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" /> -->
                                <LottieImage
                                    class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                                    :src="v?.pcImgUrl" />
                            </div>
                            <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                                <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v?.title }}</div>
                            </div>
                        </div>
                    </div>
                </ElCarouselItem>
            </ElCarousel>
            <div class="xl:h-hidden h-grid h-grid-cols-2 h-gap-4 md:h-gap-5 xl:h-gap-7">
                <div
                    v-for="(v, i) in list3?.rows"
                    class="h-group active:h-border active:h-border-primary h-flex h-flex-col h-rounded-lg h-overflow-hidden h-cursor-pointer"
                    @click="() => toDetail(v, 'uSauWhqu')">
                    <div data-aos="zoom-out" class="h-overflow-hidden h-w-full h-h-[94px] md:h-h-[215px]">
                        <!-- <NuxtImg
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" /> -->
                        <LottieImage
                            class="hover-item-img h-w-full h-h-full h-object-cover h-bg-center"
                            :src="v?.pcImgUrl" />
                    </div>
                    <div class="h-flex h-justify-center h-items-center h-bg-[#F3F4F7] h-h-[50px]">
                        <div class="h-text-xs md:h-text-sm h-px-4 h-line-clamp-1">{{ v.title }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="common-wrap wrap-y-all !h-pt-0 h-flex h-flex-col">
            <div data-aos="slide-right" class="title">文件</div>
            <div data-aos="slide-up" class="h-grid h-grid-cols-1 xl:h-grid-cols-1">
                <div
                    v-for="item in fileList?.rows"
                    class="h-cursor-pointer h-flex h-py-3 first:h-border-t h-border-b h-border-[#DDE1E6] md:h-py-5 xl:h-py-7">
                    <NuxtLink
                        class="h-flex"
                        :href="item.fileUrl"
                        target="_blank"
                    >
                        <span class="iconfont icon-icon_PDF h-text-[#FF5555] !h-text-2xl"></span>
                        <div class="h-flex h-flex-col h-ml-2">
                            <div class="h-line-clamp-2 h-text-sm md:h-text-xl">{{ item.title }}</div>
                            <div class="h-mt-1 h-line-clamp-1 h-text-secondary h-text-xs md:h-mt-2 md:h-text-sm h-text-justify">{{ item.subtitle }}</div>
                        </div>
                    </NuxtLink>
                </div>
            </div>
            <ElPagination
                class="h-self-end h-mt-4 md:h-mt-5"
                v-model:current-page="pageParams.currentPage"
                v-model:page-size="pageParams.pageSize"
                :pager-count="5"
                :background="true"
                :page-sizes="[10, 20, 30, 40]"
                :total="pageParams.total"
                :layout="higherThan('md') ? 'total, prev, pager, next, sizes, jumper' : 'pager'"
            ></ElPagination>
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'party-building-layout',
})
import ImgService from '~/service/img'
import InformationService from '~/service/information'
import DocumentService from '~/service/document'

import { storeToRefs, usePartyBuildingStore } from '#imports'
const partyBuildingStore = usePartyBuildingStore()
const { queryPartyBuildingBannerList } = partyBuildingStore
queryPartyBuildingBannerList()

const { getSize, higherThan } = useScreen();

const { data: list1 } = await ImgService.queryImgList({
    locationCodes: 'loaOGrdt',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('党员先锋数据 :>> ', list1.value?.rows)
const list1PC = computed(() => {
    const arr = []
    for (let i = 0; i < list1.value?.rows.length; i += 3) {
        arr.push(
            list1.value?.rows.slice(i, i + 3),
        )
    }
    return arr
})

const { data: list2 } = await ImgService.queryImgList({
    locationCodes: 'uSaucIqu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('党员模范数据 :>> ', list2.value?.rows)
const list2PC = computed(() => {
    const arr = []
    for (let i = 0; i < list2.value?.rows.length; i += 3) {
        arr.push(
            list2.value?.rows.slice(i, i + 3),
        )
    }
    return arr
})

const { data: list3 } = await ImgService.queryImgList({
    locationCodes: 'uSauWhqu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('优秀党员数据 :>> ', list3.value?.rows)
const list3PC = computed(() => {
    const arr = []
    for (let i = 0; i < list3.value?.rows.length; i += 3) {
        arr.push(
            list3.value?.rows.slice(i, i + 3),
        )
    }
    return arr
})

const pageParams = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0,
})
const fileList = ref({ rows: [] })
const fetchFileList = async () => {
    const params = {
        locationCodes: 'uSC78FGu',
        pageNum: pageParams.currentPage,
        pageSize: pageParams.pageSize,
        status: 1,
        websiteCode: '3',
    }
    const { data } = await DocumentService.queryDocumentList(params)
    fileList.value = data.value
    // console.log('文件数据 :>> ', fileList.value?.rows);
    pageParams.total = data.value?.total || 0
}

watchDebounced([() => pageParams.currentPage, () => pageParams.pageSize], fetchFileList, { debounce: 300, immediate: true })

const toDetail = (item, locationCode) => {
    navigateTo({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode,
        },
    })
}
</script>

<style scoped>
.exemplary-conduct-wrap {
    ::v-deep(.el-carousel__indicators.el-carousel__indicators--horizontal.el-carousel__indicators--outside) {
        .el-carousel__indicator.el-carousel__indicator--horizontal {
            .el-carousel__button {
                height: 3px;
                background-color: #D8D8D8 !important;
                opacity: 1;

            }
            &.is-active {
                .el-carousel__button {
                    background-color: #D32D1F !important;
                }
            }
        }
    }
}
</style>
