<template>
    <div class="big-event-wrap h-w-full">
        <div
            data-aos="slide-up"
            data-aos-once="true"
            data-aos-easing="cubic-bezier(0.1, 1, 1, 0.25)"
            class="common-wrap wrap-y-all">
            <div class="h-space-y-5">
                <div class="md:h-ml-10 h-relative">
                    <!-- 间隔线 -->
                    <div class="line-y"></div>
                    <div v-for="(item) in list" class="h-mb-0">
                        <div class="timeline-item">
                            <div
                                data-aos="fade-up"
                                class="timeline-item-left h-text-left h-text-xl h-text-main h-font-bold md:h-text-[28px] xl:h-text-[32px]">{{ item.year }}</div>
                            <div class="timeline-item-right h-h-20 h-pl-5 h-pb-5 md:h-pb-12">

                            </div>
                        </div>
                        <div
                            v-for="(v, index) in item.websiteEvenList"
                            :key="index"
                            data-aos="fade-up"
                            data-aos-once="true"
                            data-aos-delay="500"
                            class="timeline-item">
                            <div class="timeline-item-left h-text-center h-text-sm h-text-submain xl:h-text-right"></div>
                            <div class="timeline-item-right h-flex h-items-start h-pl-2 h-pb-7 md:h-pb-12">
                                <!-- 三角 -->
                                <!-- <div data-aos="fade-up" data-aos-once="true" data-aos-delay="700" class="h-mt-1 h-mr-10 h-w-0 h-h-0 h-border-l-[10px] h-border-t-[6px] h-border-r-0 h-border-b-[6px] h-border-transparent h-border-l-primary"></div> -->
                                <!-- 圆点 -->
                                <div data-aos="fade-up" data-aos-once="true" data-aos-delay="0" class="-h-ml-[11px] h-w-2 h-h-2 h-mt-2 h-mr-10 h-bg-primary h-rounded-lg"></div>
                                <!-- 标题 -->
                                <div data-aos="fade-up" data-aos-once="true" data-aos-delay="700" class="h-grow-0 h-w-[68px] h-mr-7 h-text-submain">{{ v.month }}</div>
                                <div data-aos="fade-up" data-aos-once="true" data-aos-delay="700" class="h-flex-1 h-text-sm h-font-medium md:h-text-base h-leading-none hover:h-bg-[#F1F4F9] h-p-4 -h-mt-4 h-rounded-lg h-text-justify">
                                    {{ v.content }}
                                </div>
                                <!-- 备注 -->
                                <!-- <div class="h-text-xs h-text-secondary h-mt-3 xl:h-text-sm h-text-justify">
                                    {{ v.content }}
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'party-building-layout',
})

import { ref } from 'vue';
import EventService from '~/service/event';
import { groupBy, timeFormat } from '~/utils/index'

import { storeToRefs, usePartyBuildingStore } from '#imports'
const partyBuildingStore = usePartyBuildingStore()
const { queryPartyBuildingBannerList } = partyBuildingStore
queryPartyBuildingBannerList()

const list = ref([])
const params = {
    locationCodes: 'CDSJVFQD',
    status: 1,
}
const response = await EventService.queryWebsiteEventList(params)
// console.error('党建大事记 :>> ', response.data.value?.data);
list.value = response.data.value?.data

</script>

<style scoped>
@keyframes growline {
    from { height: 0; }
    to { height: 100%; }
}

.big-event-wrap {
    .line-y {
        @apply h-absolute h-left-20 md:h-left-[100px] xl:h-left-[122px] h-top-0 h-bg-primary h-w-0.5 h-h-full;
        animation: growline 1.6s cubic-bezier(.56,.04,.5,1) 1.2s both;
    }

    .timeline-item {
        @apply h-flex h-items-start h-h-full;

        .timeline-item-left {
            @apply h-w-20 md:h-w-[100px] xl:h-w-[122px] xl:h-pr-5;
        }

        .timeline-item-right {
            @apply h-relative h-flex-1;
        }
    }
}
</style>
