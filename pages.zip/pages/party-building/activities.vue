<template>
    <div class="activities-wrap h-w-full">
        <div class="common-wrap wrap-y-all h-flex h-flex-col">
            <div data-aos="slide-up" data-aos-delay="400" data-aos-easing="cubic-bezier(0.1, 1, 1, 0.25)">
                <div
                    v-for="(item, index) in list?.rows"
                    :key="index"
                    class="h-group h-py-7 h-box-content h-flex h-cursor-pointer last:h-border-none h-border-b md:h-items-start xl:h-py-10" 
                    @click="() => toDetail(item)">
                    <div class="h-w-20 h-h-full h-flex h-flex-col h-items-start h-justify-start md:h-w-20">
                        <div class="h-text-base md:h-text-xl xl:h-text-2xl">{{ timeFormat(item.pushTime, 'mm-dd') }}</div>
                        <div class="h-text-sm h-text-secondary h-mt-3 xl:h-text-base">{{ timeFormat(item.pushTime, 'yyyy') }}</div>
                    </div>
                    <div class="h-flex-1 h-flex h-flex-col h-ml-3 h-justify-between h-h-full h-border-l h-pl-3 md:h-pl-4 md:h-ml-4">
                        <div class="hover-item-title h-text-sm h-line-clamp-1 h-font-bold md:h-text-base xl:h-text-xl">
                            {{ item.title }}
                        </div>
                        <div class="h-mt-4 h-text-sm h-text-secondary h-line-clamp-2 xl:h-text-base h-text-justify">
                            {{ item.excerpt }}
                        </div>
                    </div>
                    <!-- <NuxtImg class="h-ml-10 h-w-[120px] h-h-[78px] h-object-cover h-bg-center h-rounded" :src="item.coverUrl || '/images/placeholder.png'" /> -->
                    <LottieImage
                        class="h-ml-10 h-h-[78px] h-object-cover h-bg-center h-rounded"
                        width="120"
                        :src="item.coverUrl" />
                </div>
            </div>
            <ElPagination
                class="h-self-end h-mt-4 md:h-mt-5"
                v-model:current-page="pageParams.currentPage"
                v-model:page-size="pageParams.pageSize"
                :pager-count="5"
                :background="true"
                :page-sizes="[10, 20, 30, 40]"
                :total="pageParams.total"
                :layout="higherThan('md') ? 'total, prev, pager, next, sizes, jumper' : 'pager'"
            ></ElPagination>
        </div>
    </div>
</template>

<script setup>
import { useRouter } from 'nuxt/app';
import InformationService from '~/service/information'

const { getSize, higherThan } = useScreen();

import { storeToRefs, usePartyBuildingStore } from '#imports'
const partyBuildingStore = usePartyBuildingStore()
const { queryPartyBuildingBannerList } = partyBuildingStore
queryPartyBuildingBannerList()

definePageMeta({
    layout: 'party-building-layout',
})

const pageParams = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0,
})
const list = ref({ rows: [] })
const fetchList = async () => {
    const params = {
        locationCodes: 'uSCGDcVu',
        pageNum: pageParams.currentPage,
        pageSize: pageParams.pageSize,
        status: 1,
        websiteCode: '3',
    }
    const { data } = await InformationService.outQueryInformationList(params)
    list.value = data.value
    // console.log('党建动态数据 :>> ', list.value?.rows);
    pageParams.total = data.value?.total || 0
}

watchDebounced([() => pageParams.currentPage, () => pageParams.pageSize], fetchList, { debounce: 300, immediate: true })

const toDetail = item => {
    navigateTo({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode: 'uSCGDcVu',
        },
    })
}
</script>

<style scoped>
.activities-wrap {
}
</style>
