<template>
    <div class='party-building-page'>
        <NuxtPage />
    </div>
</template>

<script setup>
// 设置页面元信息
definePageMeta({
    layout: 'default',
    // 如果需要默认重定向到product页面
    middleware: [
        ({ path }) => {
            if (path === '/party-building' || path.startsWith('/zh/party-building') || path.startsWith('/en/party-building')) {
                // 获取当前语言（zh 或 en），默认 'zh'
                const lang = path.startsWith('/en/') ? 'en' : 'zh';
                return navigateTo(`/${lang}/party-building/overview`);
            }
        },
    ],
})

// import { storeToRefs, usePartyBuildingStore } from '#imports'
// const partyBuildingStore = usePartyBuildingStore()
// const { queryPartyBuildingBannerList } = partyBuildingStore
// queryPartyBuildingBannerList()
</script>
