<template>
    <div class="contact-page h-w-full">
        <div class="common-wrap wrap-y-top h-flex h-flex-col md:h-flex-row md:">
            <NuxtImg
                class="h-w-[162px] h-h-9 md:h-w-[216px] md:h-h-12 xl:h-w-[270px] xl:h-h-[60px]"
                src="/images/contact/logo-dark.svg" />
            <div class="md:h-ml-8 md:h-pl-8 md:h-border-l h-flex-1 xl:h-ml-[60px] xl:h-pl-[60px]">
                <div class="h-mt-6 h-font-medium md:h-mt-0 md:h-text-2xl md:h-text-primary">恒力集团重工有限公司（总部）</div>
                <div class="h-grid h-grid-cols-1 md:h-grid-cols-2 h-mt-3 h-text-xs h-leading-5 h-text-submain md:h-mt-8 md:h-text-sm md:h-text-main md:h-gap-x-10">
                    <div class="detail-item">{{ t('common.address') }}：{{ companyInfo.companyAddr }}</div>
                    <div class="detail-item">{{ t('common.phone') }}：{{ companyInfo.telephoneNumber }}</div>
                    <!-- <div class="detail-item">{{ t('common.fax') }}：{{ companyInfo.faxNumber }}</div> -->
                    <div class="detail-item">
                        {{ t('common.website') }}：<NuxtLink
                            target="_blank"
                            :to="companyInfo.companyWebsite"
                            >{{ companyInfo.companyWebsite }}</NuxtLink
                        >
                    </div>
                    <div class="detail-item">{{ t('common.email') }}：{{ companyInfo.reportMailbox }}</div>
                </div>
            </div>
        </div>
        <div class="common-wrap wrap-y-bottom !h-pt-0 h-overflow-hidden">
            <TencentMap class="h-w-full h-h-60 md:h-rounded-lg md:h-h-[480px]" />
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'contact-layout',
})
const { t } = useI18n()
const footerStore = useFooterStore()
const { companyInfo } = footerStore

// 顶部图片
const contactStore = useContactStore()
const { queryContactBannerList } = contactStore
queryContactBannerList()

onMounted(() => {
})
</script>

<style scoped>
.contact-page {
    @media (min-width: theme('screens.md')) {
        .detail-item {
            @apply h-mt-2;
        }
    }
}
</style>
