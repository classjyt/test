<template>
    <div class="detail-page h-w-full">
        <div class="common-wrap h-pt-[60px] h-pb-[40px] md:h-pb-[90px]">
            <div data-aos='fade' class="title">{{ detail?.title }}</div>
            <div class="h-text-secondary">{{ detail?.pushTime }}</div>
            <div class="h-mt-8 h-my-[60px] md:h-mt-[60px] h-text-sm h-leading-normal h-indent-8">
                <pre
                    class="h-whitespace-pre-wrap doc h-leading-7 h-text-justify"
                    v-html="detail?.content"></pre>
            </div>
            <div class="h-flex h-justify-between h-pt-4 h-border-t h-text-primary md:h-pt-[60px]">
                <div
                    v-if="detail?.preInformationVO"
                    class="h-group h-flex h-items-start h-w-2/5 h-cursor-pointer"
                    @click="jump(detail?.preInformationVO)">
                    <div class="h-text-nowrap">上一篇</div>
                    <div class="h-hidden md:h-block h-border-l h-ml-3 h-pl-3">
                        <div class="h-text-sm hover-item-title group-active:h-font-bold h-whitespace-pre-wrap h-line-clamp-2">{{ detail?.preInformationVO?.title }}</div>
                        <div class="h-mt-3 h-text-xs h-text-secondary h-line-clamp-2 h-text-justify">{{ detail?.preInformationVO?.subtitle }}</div>
                    </div>
                </div>
                <div v-else></div>
                <div
                    v-if="detail?.nextInformationVO"
                    class="h-group h-flex h-items-start h-justify-end h-w-2/5 h-cursor-pointer"
                    @click="jump(detail?.nextInformationVO)">
                    <div class="h-hidden md:h-block h-border-r h-mr-3 h-pr-3 h-text-right">
                        <div class="h-text-sm hover-item-title group-active:h-font-bold h-whitespace-pre-wrap h-line-clamp-2">{{ detail?.nextInformationVO?.title }}</div>
                        <div class="h-mt-3 h-text-xs h-text-secondary h-line-clamp-2 h-text-justify">{{ detail?.nextInformationVO?.subtitle }}</div>
                    </div>
                    <div class="h-text-nowrap">下一篇</div>
                </div>
                <div v-else></div>
            </div>
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'detail-layout',
})

import { onMounted } from 'vue'
import { watch } from 'vue'
import InformationService from '~/service/information'
const { scrollToTop } = useScroll()

const route = useRoute()
const router = useRouter()

// const detail = ref({})

// const response = await InformationService.queryInformationDetailByCode(params)
// console.error('信息详情 :>> ', response)
// detail.value = response.data.value?.data

// const params = {
//     code: route.query.code,
//     locationCode: route.query.locationCode,
// }
// const { data, refresh } = await InformationService.queryInformationDetailByCode(params)
// console.error('信息详情 :>> ', data)
// detail.value = data.value?.data

const { data: detail, refresh } = await useAsyncData(
  'detail',
  () => InformationService.queryInformationDetailByCode({
    code: route.query.code,
    locationCode: route.query.locationCode,
  }).then(res => res.data.value?.data),
  {
    watch: [() => route.query.code],
  }
)

// watch(
//     () => route.query.code,
//     () => {
//         // console.log('详情接口调用了 :>> ')
//         refresh()
//         // queryDetail()
//     },
// )

// watch(
//     () => detail.value?.content,
//     async () => {
//         await nextTick()
//         applyImageCentering()
//     },
// )

watch(
  () => detail.value?.content,
  async () => {
    await nextTick()
    applyImageCentering()
  }
)

function applyImageCentering() {
    const container = document.querySelector('.doc')
    if (!container) return
    container.querySelectorAll('img').forEach(img => {
        img.style.display = 'block'
        img.style.margin = '0 auto'
        img.style.maxWidth = '100%'
    })
}

onMounted(() => {
    applyImageCentering()
})

const queryDetail = async () => {
    try {
        const params = {
            code: route.query.code,
            locationCode: route.query.locationCode,
        }
        const response = await InformationService.queryInformationDetailByCode(params)
        // console.error('信息详情 :>> ', response)
        detail.value = response.data.value?.data
    } catch (error) {
        // console.error('error :>> ', error)
    }
}

// queryDetail()

const jump = item => {
    router.replace({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode: route.query.locationCode,
        },
    })
    scrollToTop()
}
</script>

<style scoped>
.detail-page {}
</style>
