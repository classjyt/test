<template>
    <div class="report-wrap h-w-full">
        <div class="common-wrap h-py-[60px] h-flex h-flex-col xl:h-py-[100px]">
            <div class="h-overflow-hidden h-flex h-justify-between h-items-center h-w-full">
                <div data-aos='slide-right' class="title !h-flex-1">{{ t('news.specialReports') }}</div>
                <div data-aos='slide-left' class="h-hidden h-w-[260px] md:h-block">
                    <el-input
                        v-model="keyword"
                        class="h-mb-3 md:h-mb-5 xl:h-mb-10"
                        :placeholder="t('common.searchPlaceholder')"
                        size="large"></el-input>
                </div>
            </div>
            <div
                data-aos="slide-up"
                data-aos-offset='30'
                data-aos-delay='300'
                data-aos-easing="cubic-bezier(0.1, 1, 1, 0.25)">
                <div
                    v-for="(item, index) in reportList?.rows"
                    :key="index"
                    class="h-group h-py-7 h-box-content h-flex h-cursor-pointer first:h-border-t h-border-b md:h-h-[50px]"
                    @click="() => toDetail(item)">
                    <div class="h-w-[68px] h-flex h-flex-col h-items-start h-justify-between h-text-sm md:h-w-20 h-h-[66px] md:h-h-[50px] xl:h-h-[56px]">
                        <div class="h-text-base md:h-text-xl xl:h-text-2xl">{{ timeFormat(item.pushTime, 'mm-dd') }}</div>
                        <div class="h-text-sm h-text-submain xl:h-text-base">{{ timeFormat(item.pushTime, 'yyyy') }}</div>
                    </div>
                    <div class="h-h-[66px] md:h-h-[50px] xl:h-h-[56px] h-bg-[#DDE1E6] h-w-[1px] h-mx-3 md:h-mx-4"></div>
                    <div class="hover-item-title group-active:h-text-primary h-flex-1 h-text-sm h-line-clamp-3 md:h-text-base md:!h-line-clamp-1 h-font-medium xl:h-text-xl">
                        {{ item.title }}
                    </div>
                    <span class="iconfont icon-a-Arrow-right3 h-text-main h-hidden md:h-block md:!h-text-2xl xl:!h-text-[32px]"></span>
                </div>
            </div>
            <ElPagination
                class="h-self-end h-mt-4 md:h-mt-5"
                v-model:current-page="pageParams.currentPage"
                v-model:page-size="pageParams.pageSize"
                :pager-count="5"
                :background="true"
                :page-sizes="[10, 20, 30, 40]"
                :total="pageParams.total"
                :layout="higherThan('md') ? 'total, prev, pager, next, sizes, jumper' : 'pager'"
            ></ElPagination>
        </div>
    </div>
</template>

<script setup>
definePageMeta({
    layout: 'news-layout',
})
const { t } = useI18n()
import InformationService from '~/service/information'
import { timeFormat } from '~/utils/index'
const { getSize, higherThan } = useScreen();

const newsStore = useNewsStore()
const { queryNewsBannerList } = newsStore
queryNewsBannerList()

const keyword = ref('')
const pageParams = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0,
})
const reportList = ref({ rows: [] })
const fetchReportList = async () => {
    const params = {
        keyword: keyword.value,
        locationCodes: 'uSaQecMu',
        pageNum: pageParams.currentPage,
        pageSize: pageParams.pageSize,
        status: 1,
        websiteCode: '3',
    }
    const { data } = await InformationService.outQueryInformationList(params)
    reportList.value = data.value
    // console.log('媒体聚焦数据 :>> ', reportList.value?.rows)
    pageParams.total = data.value?.total || 0
}

watchDebounced([() => pageParams.currentPage, () => pageParams.pageSize, keyword], fetchReportList, { debounce: 300, immediate: true })

const toDetail = item => {
    navigateTo({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode: 'uSaQecMu',
        },
    })
}
</script>

<style scoped>
.report-wrap {
}
</style>
