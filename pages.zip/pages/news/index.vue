<template>
    <div class='product-page'>
        <NuxtPage />
    </div>
</template>

<script setup>
// 设置页面元信息
definePageMeta({
    layout: 'default',
    // 如果需要默认重定向到product页面
    middleware: [
        ({ path }) => {
            if (path === '/news' || path.startsWith('/zh/news') || path.startsWith('/en/news')) {
                // 获取当前语言（zh 或 en），默认 'zh'
                const lang = path.startsWith('/en/') ? 'en' : 'zh';
                return navigateTo(`/${lang}/news/company-news`);
            }
        },
    ],
})
</script>
