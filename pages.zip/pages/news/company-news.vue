<template>
    <div class="company-news-wrap h-w-full">
        <div class="common-wrap wrap-y-all h-flex h-flex-col xl:h-items-start">
            <div class="h-overflow-hidden h-flex h-justify-between h-items-center h-w-full">
                <div data-aos='slide-right' class="title !h-flex-1">{{ t('news.companyNews') }}</div>
                <div data-aos='slide-left' class="h-hidden h-w-[260px] md:h-block">
                    <el-input
                        v-model="keyword"
                        class="h-mb-3 md:h-mb-5 xl:h-mb-10"
                        :placeholder="t('common.searchPlaceholder')"
                        size="large"></el-input>
                </div>
            </div>
            <div class="h-grid h-grid-cols-1 md:h-grid-cols-2 xl:h-grid-cols-3 md:h-gap-9">
                <div
                    v-for="(item, index) in newsList?.rows"
                    :class="['first:h-pt-0 h-py-7 md:h-p-0 h-border-b md:h-border-b-0']">
                    <div
                        :class="['h-h-full h-group h-box-border h-flex h-justify-between h-w-full md:h-flex-col md:h-rounded-lg md:h-overflow-hidden h-cursor-pointer md:active:h-border active:h-border-[#DCDFE6]', index === 0 ? 'h-flex-col h-rounded-lg h-overflow-hidden active:h-border' : '']"
                        @click="() => toDetail(item)">
                        <div data-aos='zoom-out' :class="['h-rounded-lg h-overflow-hidden h-h-20 md:h-h-[280px] md:h-w-full md:h-rounded-none h-bg-slate-200', index === 0 ? 'h-w-full h-rounded-none h-h-[190px]' : 'h-w-2/5']">
                            <!-- <NuxtImg
                                class="h-w-full h-h-full h-object-cover h-bg-center hover-item-img"
                                :src="item.coverUrl || '/images/placeholder.png'" /> -->
                            <LottieImage
                                class="h-w-full h-h-full h-object-cover h-bg-center hover-item-img"
                                :src="item.coverUrl" />
                        </div>
                        <div :class="`h-flex h-flex-col h-flex-1 h-justify-between h-ml-5 md:h-ml-0 md:h-px-4 md:h-py-7 md:h-bg-[#F3F4F7] md:h-h-[220px] group-active:h-bg-white ${index == 0 ? 'h-bg-[#F3F4F7] h-px-4 h-py-5 !h-ml-0' : ''}`">
                            <div :class="`hover-item-title h-line-clamp-2 h-font-medium h-text-sm md:h-text-xl xl:h-text-2xl ${index === 0 ? 'h-text-xl' : ''}`">{{ item.title }}</div>
                            <div :class="`h-hidden h-text-sm h-mt-6 h-text-secondary md:h-mt-4 md:h-flex md:!h-line-clamp-2 h-text-ellipsis h-text-justify ${index === 0 ? '!h-block' : ''}`">
                                {{ item.excerpt }}
                            </div>
                            <div class="h-text-sm h-mt-5 md:h-mt-8 h-text-submain h-font-medium h-text-right">{{ timeFormat(item.pushTime) }}</div>
                        </div>
                    </div>
                </div>
            </div>
            <ElPagination
                class="h-self-end h-mt-4 md:h-mt-5"
                v-model:current-page="pageParams.currentPage"
                v-model:page-size="pageParams.pageSize"
                :pager-count="5"
                :background="true"
                :page-sizes="[10, 20, 30, 40]"
                :total="pageParams.total"
                :layout="higherThan('md') ? 'total, prev, pager, next, sizes, jumper' : 'pager'"></ElPagination>
        </div>
    </div>
</template>

<script setup>
import { ElPagination } from 'element-plus'
import { definePageMeta, useNewsStore, timeFormat } from '#imports'
import InformationService from '~/service/information'
import { watchDebounced } from '@vueuse/core'

const { t } = useI18n()
const { getSize, higherThan } = useScreen()
const newsStore = useNewsStore()
const { queryNewsBannerList } = newsStore

queryNewsBannerList()

definePageMeta({
    layout: 'news-layout',
})

const keyword = ref('')
const pageParams = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0,
})
const newsList = ref({ rows: [] })
const fetchNewsList = async () => {
    const params = {
        keyword: keyword.value,
        locationCodes: 'uSaPecVu',
        pageNum: pageParams.currentPage,
        pageSize: pageParams.pageSize,
        status: 1,
        websiteCode: '3',
    }
    const { data } = await InformationService.outQueryInformationList(params)
    newsList.value = data.value
    // console.log('新闻数据 :>> ', newsList.value?.rows)
    pageParams.total = data.value?.total || 0
}

watchDebounced([() => pageParams.currentPage, () => pageParams.pageSize, keyword], fetchNewsList, { debounce: 300, immediate: true })

const toDetail = item => {
    navigateTo({
        path: '/news/detail',
        query: {
            code: item.informationCode,
            locationCode: 'uSaPecVu',
        },
    })
}
</script>

<style scoped>
.company-news-wrap {
}
</style>
