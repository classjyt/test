<template>
    <div id="editor" class="privacy" v-html="content">
    </div>
</template>
<script lang="ts" setup>
    // import DOMPurify from "dompurify";
    // import { wangeditor } from 'wangeditor'
    import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
    import InformationService from '~/service/information'

    const content = ref('')
    const editor = ref()

    const getData = async () => {
        const { data } = await InformationService.protocolList(5);
        content.value = data.value.data[0].content
        // editor.value = new wangeditor("#editor");
        // editor.value.config.menus = [];
        // editor.value.config.height = "100%";
        // editor.value.create();
        // editor.value.disable();
        // editor.value.txt.html = data.value.data[0].content
    }

    await getData();

    onMounted(() => {
       
    })

</script>


<style scoped lang="less" >
.privacy {
    padding: 0 24px 48px;
    height: 100%;
    overflow: auto;
    word-break: break-all;

    // /deep/ .w-e-menu-tooltip,
    // /deep/ .w-e-menu,
    // /deep/ .w-e-icon-fullscreen,
    // /deep/ .w-e-toolbar {
    //     display: none;
    // }

    // /deep/ .w-e-text-container {
    //     border: none !important;
    // }
    /deep/ table{
        border: 1px solid #ccc;
        th{
            background-color: #f1f1f1;
            border: 1px solid #ccc;
        }
        tr{
            td{
                border: 1px solid #ccc;
            }
        }
    }
}

</style>
