<template>
    <div class="app-download" >
        <!-- <LottieImage src="/images/contact/img_h5_bg.png" /> -->
        <img class="app-bg" src="/images/contact/img_h5_bg.png" />
        <div class="app-logo">
            <img src="/images/contact/img_h5_logo.png" />
        </div>
        <!-- <div class="app-ios" >
            <div class="app-area">选择您所在的地区进行下载</div>
            <div class="app-button" @click="downloadIOSApp(0)">中国大陆</div>
            <div class="app-button other" @click="downloadIOSApp(1)">
                Other Country/Region
            </div>
        </div> -->
        <div class="app-android">
            <div class="app-button" @click="downloadAndroidApp">立即下载</div>
        </div>
        <div class="app-info">iOS和Android共同适用</div>
        <div class="app-info">苹果设备请使用Safari浏览器打开</div>

        <div :class="{ wxTips: true, hide: !showWxTips }">
            <p>
                <img src="/images/contact/icon_text.png" />
            </p>
            <div>
                <button @click="showWxTips = false">我知道了</button>
            </div>
        </div>
    </div>
</template>

<script lang="ts" setup>
    import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
    import InformationService from '~/service/information'

    const isIOS = ref(false)
    const showWxTips = ref(false)
    const isAndroid = ref(false)
    // import { isWxBrowser } from '~/utils/index'
    // import store from "@/store";
    // import request from "@/utils/request";
    // import { getLatestVersion } from "@/api/dictionary";

    onMounted(()=>{
        if(process.client){
            if(navigator&&navigator.userAgent){
                const ua = navigator.userAgent
                isIOS.value = ua.includes('iPhone') || ua.includes('Mac')
                // isAndroid.value = ua.indexOf('Android')>-1 || ua.indexOf('Linux')>-1
                showWxTips.value = /micromessenger/.test(ua.toLowerCase())
            }
        }
        document.title = "HENGLINK APP官方下载专区";
    })

    const downloadAndroidApp = async () => {
        if (showWxTips.value) {
            showWxTips.value = true;
            return;
        }
        if(isIOS.value){
            
        }else{
            const { data } = await InformationService.getLatestVersion();
            console.log('111111',data.value, data.value.data, data.value.data.downloadUrl )
            // return
            const src = data.value.data.downloadUrl;
            const form = document.createElement("form");
            form.action = src;
            document.getElementsByTagName("body")[0].appendChild(form);
            form.submit();
        }

    }

    const downloadIOSApp = async (type: number) => {
        if (showWxTips.value) {
            showWxTips.value = true;
            return;
        }
        const { data } = await InformationService.getIOSApp(type);
        console.log('22222',data.value, )
    }

</script>

<style lang="less" scoped>
.app-download {
    width: 100%;
    min-height: 100vh;
    overflow: hidden;
    .app-bg{
        width: 100%;
        height: 430px;
    }
    .app-logo {
        width: 100%;
        height: auto;
        position: absolute;
        top: 90px;
        display: flex;
        justify-content: center;
        img {
            width: 290px;
            height: 323px;
        }
    }

    .app-area {
        text-align: center;
        line-height: 22px;
        font-family: PingFang SC, PingFang SC;
        font-weight: 400;
        font-size: 16px;
        color: #606266;
        margin-bottom: 12px;
    }

    .app-button {
        width: 320px;
        margin: 0 auto;
        border-radius: 8px;
        margin-bottom: 12px;
        background: #006fff;
        font-family: PingFang SC, PingFang SC;
        font-weight: 600;
        font-size: 16px;
        color: #ffffff;
        line-height: 48px;
        text-align: center;

        &:hover {
        background: #0064e6;
        }

        &.other {
        background: #004097;

        &:hover {
            background: #023478;
        }
        }
    }

    .app-info {
        font-family: PingFang SC, PingFang SC;
        font-weight: 400;
        font-size: 14px;
        color: #9e9e9e;
        line-height: 20px;
        text-align: center;
        margin-bottom: 6px;
    }

    .app-ios {
        overflow: hidden;
        margin-bottom: 10px;
    }

    .wxTips {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.8);
        filter: alpha(opacity=80);
        z-index: 100;
        display: block;
        &.hide {
        display: none;
        }
        & > p {
        text-align: right;
        padding: 0 5%;
        img {
            width: 222px;
            height: 125px;
        }
        }
        & > div {
        margin-top: 67px;
        button {
            border: 1px solid #fff;
            border-radius: 18px;
            height: 36px;
            width: 114px;
            margin: 0 auto;
            text-align: center;
            font-size: 14px;
            background-color: transparent;
            color: #fff;
        }
        }
    }
}
</style>
