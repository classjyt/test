<template>
    <div class="development-page h-w-full">
        <div class="">
            <div data-aos='fade' class="h-relative h-flex h-h-[435px] h-flex-col h-w-full md:h-h-[600px] xl:h-h-screen md:h-relative">
                <!-- <NuxtImg data-aos='fade' class="h-w-full h-h-full h-object-cover h-bg-center" :src="bannerList?.rows[0]?.pcImgUrl" /> -->
                <LottieImage
                    data-aos='fade'
                    class="h-w-full h-h-full h-object-cover h-bg-center"
                    :src="bannerList?.rows[0]?.pcImgUrl" />
                <div data-aos='slide-up' class="opacity-0 h-hidden md:h-block h-absolute h-bottom-[120px] h-w-4/5 h-left-0 h-bg-[#0C1A2659] h-backdrop-blur-[20px] h-px-7 h-py-10 h-text-white h-text-2xl xl:h-text-[32px] xl:h-leading-[48px] xl:h-px-10 xl:h-bottom-[220px]" :style="{ paddingLeft: paddingLeft}">
                    <div data-aos='slide-up' class="h-font-light">{{ bannerList?.rows[0]?.title }}</div>
                    <div data-aos='slide-up' data-aos-delay="200" class="h-mt-8 h-font-medium h-text-justify">{{ bannerList?.rows[0]?.subtitle }}</div>
                    <div class="h-relative h-bg-white h-h-[1px] h-opacity-60 h-mt-10">
                        <div class="h-absolute h-top-[-1.5px] h-left-0 h-h-1 h-bg-white h-w-[200px]"></div>
                    </div>
                </div>
            </div>
            <div class="common-wrap h-bg-[#0C1A26] md:h-hidden">
                <div class="h-px-2 h-py-10 h-text-white">
                    <div data-aos='slide-up' class="">{{ bannerList?.rows[0]?.title }}</div>
                    <div data-aos='slide-up' data-aos-delay="200" class="h-mt-8 h-font-medium h-text-justify">{{ bannerList?.rows[0]?.subtitle }}</div>
                    <div class="h-relative h-bg-white h-h-[1px] h-opacity-60 h-mt-10">
                        <div class="h-absolute h-top-[-1.5px] h-left-0 h-h-1 h-bg-white h-w-2/3"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Social Responsibility -->
        <div class="wrap-y-top common-wrap xl:h-pt-20">
            <div data-aos='slide-right' class="title opacity-0">{{ responsibility?.rows?.[0]?.title }}</div>
            <div data-aos='slide-up' class="h-flex h-flex-col md:h-flex-row">
                <NuxtImg
                    class="h-w-auto h-h-[240px] h-object-cover"
                    :src="responsibility?.rows?.[0]?.coverUrl || '/images/placeholder.png'" />
                <!-- <LottieImage
                    class="h-w-auto h-h-[240px] h-object-cover"
                    :src="responsibility?.rows?.[0]?.coverUrl" /> -->
                <div class="h-text-sm h-mt-5 md:h-mt-0 md:h-ml-7 md:h-text-base md:h-leading-7 h-text-justify">{{ responsibility?.rows?.[0]?.subtitle }}</div>
            </div>
        </div>

        <!-- Charity Activities -->
        <div class="wrap-y-center !h-py-[100px] h-bg-[#F1F4F9]">
            <div class="common-wrap">
                <div data-aos='slide-right' class="title">Charity Activities</div>
                <div class="h-gap-x-3 h-gap-y-5 md:h-gap-5 h-grid h-grid-cols-2 md:h-grid-cols-3 xl:h-grid-cols-4 xl:h-gap-7">
                    <div
                        v-for="item in activities?.rows"
                        class="h-overflow-hidden h-rounded-lg h-flex md:h-mt-0 h-flex-col">
                        <!-- <NuxtImg
                            data-aos='zoom-out'
                            class="h-w-full h-h-[100px] md:h-h-60 h-object-cover"
                            :src="item.pcImgUrl" /> -->
                        <LottieImage
                            data-aos='zoom-out'
                            class="h-w-full h-h-[100px] md:h-h-60 h-object-cover"
                            :src="item.pcImgUrl" />
                        <div class="h-flex-1 h-flex h-flex-col h-bg-[#FFF] h-px-4 h-py-4 md:h-px-5 h-overflow-hidden">
                            <div class="h-text-sm md:h-text-base xl:h-text-xl">{{ item.title }}</div>
                            <div class="h-mt-1.5 md:h-mt-2 h-text-xs h-leading-5 h-text-[#606266] md:h-text-sm">
                                <div class="h-line-clamp-3 h-text-justify">{{ item.subtitle }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Environmental Advocacy -->
        <div class="common-wrap wrap-y-center">
            <div data-aos='slide-right' class="title md:h-w-full">Environmental Advocacy</div>
            <Swiper
                :modules="[Autoplay, Navigation, Pagination]"
                :pagination="{
                    clickable: true,
                    el: '.swiper-pagination-three',
                }"
                :slidesPerView="1.1"
                effect="flip"
                :space-between="32"
                :breakpoints="{
                    320: { slidesPerView: 1.2 },
                    640: { slidesPerView: 1.2 },
                    768: { slidesPerView: 1.5 },
                    1024: { slidesPerView: 2 },
                    1280: { slidesPerView: 2 },
                }"
                class="h-w-full !h-m-0">
                <SwiperSlide
                    v-for="(item, index) in env?.rows"
                    :class="['h-flex h-flex-col h-rounded-lg h-overflow-hidden h-w-[calc(100vw-48px)] md:h-w-auto h-transition-all h-duration-500', environmentIndex === 0 ? 'h-translate-x-0' : '-h-translate-x-full']"
                    :key="index">
                    <!-- <NuxtImg
                        data-aos='zoom-out'
                        class="h-w-full h-h-[280px] h-object-cover"
                        :src="item.pcImgUrl" /> -->
                    <LottieImage
                        data-aos='zoom-out'
                        class="h-w-full h-h-[280px] h-object-cover"
                        :src="item.pcImgUrl" />
                    <div class="h-flex h-flex-col h-justify-between h-bg-[#F9FBFD] h-px-4 h-py-7 h-h-[310px] md:h-h-[300px] xl:h-h-[300px]">
                        <div class="h-sh h-shrink-0 h-font-medium h-text-sm md:h-text-xl xl:h-text-28px h-line-clamp-2">{{ item.title }}</div>
                        <ElScrollbar class="h-flex-1 h-mt-4 h-text-xs md:h-text-sm h-text-secondary h-text-justify">{{ item.subtitle }}</ElScrollbar>
                    </div>
                </SwiperSlide>
            </Swiper>
            <!-- Swiper 默认样式分页器外置容器 -->
            <div class="swiper-pagination-three h-mt-4 h-text-center"></div>
        </div>

        <!-- Our Public Welfare Footprint -->
        <div class="common-wrap wrap-y-center !h-pt-0">
            <div data-aos='slide-right' class="title md:h-w-full">Our Public Welfare Footprint</div>
            <div data-aos='slide-up' class="h-grid h-grid-cols-2 h-overflow-hidden h-gap-3 md:h-gap-5 md:h-grid-cols-4 xl:h-gap-7">
                <div v-for="item in footprint?.rows" class=" h-grid h-place-items-center h-gap-6 h-py-6 h-border h-border-[#DCDFE6] h-rounded h-h-[140px] md:h-rounded-lg md:h-py-9 md:h-h-[200px] xl:h-h-[284px] xl:h-py-[60px]">
                    <div class="h-text-base h-text-[#2FB350] md:h-text-2xl xl:h-text-3xl" style="font-family: 'PangMenZhengDao';">
                        <CountUp
                            v-if="!isNaN(item.subtitle)"
                            class="h-line-clamp-1 h-break-all"
                            :end="Number(item.subtitle)"
                            duration="0.5" />
                        <div v-else>
                            {{ item.subtitle }}
                        </div>
                    </div>
                    <div class="h-text-secondary h-text-xs md:h-text-sm xl:h-text-base">
                        {{ item.title }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { definePageMeta, useSocialWelfareStore } from '#imports'
import InformationService from '~/service/information'
import ImgService from '~/service/img'
import { ref, computed, onMounted, watchEffect } from 'vue';
import { ElScrollbar } from 'element-plus';

import 'swiper/css'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
import { Swiper, SwiperSlide } from 'swiper/vue'
import { Autoplay, Pagination, Navigation } from 'swiper/modules'

definePageMeta({
    layout: 'social-welfare-layout',
})
const elCarouselRef = ref()

const environmentIndex = ref(0)

const { paddingLeft: left } = useScreen()

const paddingLeft = computed(() => left.value)

// 顶部图片
// const socialWelfareStore = useSocialWelfareStore()
// const { querySocialWelfareBannerList } = socialWelfareStore
// querySocialWelfareBannerList()

// 顶部图片
const { data: bannerList } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uSscDeMu',
    pageNum: 1,
    pageSize: 1,
    status: 1,
})
// console.error('社会公益顶部图片 :>> ', bannerList.value?.rows);

// 社会责任 Social Responsibility
const { data: responsibility } = await InformationService.outQueryInformationList({
    locationCodes: 'uSscSCMu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('社会责任 Social Responsibility :>> ', responsibility.value?.rows);

// 慈善活动 Charity Activities 
const { data: activities } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uEGcDeMu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('慈善活动 Charity Activities :>> ', activities.value?.rows);


// 环境倡导 Environmental Advocacy
const { data: env } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uSscVHMu',
    pageNum: 1,
    pageSize: 6,
    status: 1,
    websiteCode: '3',
})
// console.error('环境倡导 Environmental Advocacy :>> ', env.value?.rows);

// 足迹公益
const { data: footprint } = await ImgService.queryImgList({
    keyword: '',
    locationCodes: 'uSJUDeMu',
    pageNum: 1,
    pageSize: 10,
    status: 1,
    websiteCode: '3',
})
// console.error('足迹公益 :>> ', footprint.value?.rows);

</script>

<style scoped>
.development-page {
    .env-green-item {
        @apply h-border-[#AEE9BD] h-rounded-[20px] h-p-2 h-border h-text-nowrap h-text-xs h-text-[#2FB350];
    }
}
</style>
