<template>
    <div class="values-wrap h-w-full">
        <div class="common-wrap wrap-y-all">
            <div data-aos='slide-right' class="title md:h-w-full">{{ t('product.shipProducts') }}</div>
            <div data-aos='slide-up' class="h-overflow-hidden h-flex h-flex-col md:h-flex-row md:h-items-start md:h-rounded-lg">
                <div class="h-flex h-flex-col h-rounded-lg h-bg-[#EEF2F7E5] h-px-5 h-py-8 md:h-px-7 md:h-w-[384px] md:h-h-[390px] md:h-rounded-none xl:h-h-[600px] xl:h-px-[60px] xl:h-pt-[80px] xl:h-pb-[60px] xl:h-w-[572px] md:h-order-2">
                    <div :key="realIndex" data-aos="slide-up" class="h-text-base h-text-primary md:h-text-xl xl:h-text-[28px] xl:h-leading-[36px] h-line-clamp-2">{{ productList[realIndex]?.title }}</div>
                    <div :key="realIndex" data-aos="slide-up" class="h-mt-2 h-text-sm md:h-text-base md:h-leading-8 xl:h-mt-3 xl:h-text-xl h-line-clamp-2 h-text-justify">{{ productList[realIndex]?.subtitle }}</div>
                    <ElScrollbar :key="realIndex" data-aos="slide-up" class="h-my-10 h-text-sm md:h-flex-1 h-overflow-scroll xl:h-text-base">
                        <pre class="h-whitespace-pre-wrap h-text-justify">{{ productList[realIndex]?.excerpt }}</pre>
                    </ElScrollbar>
                    <div class="h-mt-auto h-flex" v-if="productList?.length">
                        <div class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary h-mr-3"
                            @click="() => elCarouselRef?.prev()"
                        >
                            <span class="iconfont icon-zuojiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                        <div class="h-flex h-justify-center h-items-center h-mt-5 h-w-[38px] h-h-6 h-rounded-[20px] h-border h-border-[#DCDFE6] h-cursor-pointer h-bg-white h-bg-opacity-60 hover:h-bg-opacity-100 active:h-border-primary"
                            @click="() => elCarouselRef?.next()"
                        >
                            <span class="iconfont icon-icon_jiantou h-text-primary !h-text-[9px]"></span>
                        </div>
                    </div>
                </div>
                <div class="h-group h-overflow-hidden h-relative h-rounded-md h-w-full h-h-[206px] h-mt-3 md:h-mt-0 md:h-h-[390px] md:h-rounded-none md:h-flex-1 xl:h-h-[600px] md:h-order-1">
                    <el-carousel
                        ref="elCarouselRef"
                        trigger="click"
                        height="100%"
                        class="h-h-full"
                        indicator-position="none"
                        arrow="hover"
                        :autoplay="true"
                        :interval="4000"
                    >
                        <el-carousel-item
                            v-for="(item, index) in productList"
                            :key="index">
                            <!-- <NuxtImg
                                class="h-w-full h-h-full h-object-cover"
                                :src="item.coverUrl || '/images/placeholder.png'" /> -->
                            <LottieImage
                                class="h-w-full h-h-full h-object-cover hover-item-img"
                                :src="item.coverUrl" />
                        </el-carousel-item>
                    </el-carousel>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ElCarousel, ElCarouselItem, ElScrollbar } from 'element-plus'
import { definePageMeta, useProductStore } from '#imports'
import InformationService from '~/service/information'

definePageMeta({
    layout: 'product-layout',
})
const { t } = useI18n()

const productStore = useProductStore()
const { queryProductBannerList } = productStore
queryProductBannerList()

const elCarouselRef = ref()
const realIndex = computed(() => {
    const index = elCarouselRef.value?.activeIndex ?? 0
    const length = productList.value?.length
    return (index % length)
})

const productList = ref([])
const params = {
    keyword: '',
    locationCodes: 'uSaaecTu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
}
const response = await InformationService.outQueryInformationList(params)
// console.log('船舶产品数据 :>> ', response.data.value?.rows);
productList.value = response.data.value?.rows

</script>

<style scoped>
/* .values-wrap {
} */
</style>
