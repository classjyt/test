<template>
    <div class="service-wrap h-w-full">
        <div class="common-wrap wrap-y-all md:h-pb-[100px] xl:h-pb-[150px]">
            <div class="h-flex h-flex-col md:h-flex-row h-rounded-lg h-overflow-hidden">
                <!-- <NuxtImg
                    data-aos='zoom-out'
                    class="h-object-cover h-h-[206px] h-w-full md:h-w-1/3 md:h-h-[280px] xl:h-w-[640px] xl:h-h-[320px]"
                    :src="list1?.rows[0]?.coverUrl || '/images/placeholder.png'"
                    fit="inside" /> -->
                <LottieImage
                    data-aos='zoom-out'
                    class="h-object-cover h-h-[206px] h-w-full md:h-h-[280px] md:h-w-[42%] xl:h-h-[320px] h-rounded-lg md:h-rounded-none"
                    :src="list1?.rows[0]?.coverUrl"
                    fit="inside" />
                <div
                    data-aos='slide-up'
                    class="h-mt-3 h-px-5 h-py-8 md:h-p-7 md:h-py-8 md:h-mt-0 md:h-w-2/3 md:h-flex md:h-flex-col md:h-justify-between md:h-h-[280px] xl:h-h-[320px] h-bg-[#EEF2F7E5] md:h-relative xl:h-px-[60px] xl:h-py-[60px] xl:h-justify-start xl:h-flex-1 h-backdrop-blur h-rounded-lg md:h-rounded-none">
                    <div class="h-text-primary h-min-h-8 h-font-medium h-text-xl xl:h-text-2xl h-line-clamp-1">{{ list1?.rows[0]?.title }}</div>
                    <ElScrollbar data-aos-delay="200" class="h-text-sm h-mt-10 md:h-mt-[32px] xl:h-mt-10 xl:h-text-base">
                        <div class="h-text-sm !h-leading-7 h-text-justify" v-html="list1?.rows[0]?.content"></div>
                    </ElScrollbar>
                </div>
            </div>

            <div class="h-flex h-flex-col h-mt-[60px] md:h-mt-[80px] md:h-flex-row xl:h-mt-[100px] h-rounded-lg h-overflow-hidden">
                <!-- <NuxtImg
                    data-aos='zoom-out'
                    class="h-object-cover h-h-[206px] h-w-full md:h-w-1/3 md:h-h-[280px] xl:h-w-[640px] xl:h-h-[320px]"
                    :src="list2?.rows[0]?.coverUrl || '/images/placeholder.png'"
                    fit="inside" /> -->
                <LottieImage
                    data-aos='zoom-out'
                    class="md:h-order-2 h-object-cover h-h-[206px] h-w-full md:h-h-[280px] md:h-w-[42%] xl:h-h-[320px]  h-rounded-lg md:h-rounded-none"
                    :src="list2?.rows[0]?.coverUrl"
                    fit="inside" />
                <div
                    data-aos='slide-up'
                    class="md:h-order-1 h-mt-3 h-px-5 h-py-8 md:h-p-7 md:h-py-8 md:h-mt-0 md:h-w-2/3 md:h-flex md:h-flex-col md:h-justify-between md:h-h-[280px] xl:h-h-[320px] h-bg-[#EEF2F7E5] md:h-relative xl:h-px-[60px] xl:h-py-[60px] xl:h-justify-start xl:h-flex-1 h-backdrop-blur h-rounded-lg md:h-rounded-none">
                    <div class="h-text-primary h-min-h-8 h-font-medium h-text-xl xl:h-text-2xl h-line-clamp-1">{{ list2?.rows[0]?.title }}</div>
                    <ElScrollbar data-aos-delay="200" class="h-text-sm h-mt-10 md:h-mt-[32px] xl:h-mt-10 xl:h-text-base">
                        <div class="h-text-sm !h-leading-7 h-text-justify" v-html="list2?.rows[0]?.content"></div>
                    </ElScrollbar>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ElScrollbar } from 'element-plus';
import InformationService from '~/service/information'
definePageMeta({
    layout: 'product-layout',
})

const productStore = useProductStore()
const { queryProductBannerList } = productStore
queryProductBannerList()

const { data: list1 } = await InformationService.outQueryInformationList({
    locationCodes: 'uSaaecVu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('研发实力与技术团队数据 :>> ', list1.value?.rows)

const { data: list2 } = await InformationService.outQueryInformationList({
    locationCodes: 'uSaRecVu',
    pageNum: 1,
    pageSize: 100,
    status: 1,
    websiteCode: '3',
})
// console.log('先进造船技术数据 :>> ', list2.value?.rows)

</script>

<style scoped>
.service-wrap {
}
</style>
