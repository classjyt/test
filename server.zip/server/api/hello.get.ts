import CommonService from "../../service/common"

export default defineEventHandler(event => {
    // return CommonService.queryInfo()
    return {
        message: 'Hello, this is a Nuxt 3 API!',
        time: new Date().toISOString(),
    }
})
