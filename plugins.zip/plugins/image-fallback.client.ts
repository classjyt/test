import { defineNuxtPlugin } from 'nuxt/app';

export default defineNuxtPlugin(() => {
    const fallbackSrc = '/images/placeholder.png'

    // 用事件委托给全局 img 标签
    // document.addEventListener(
    //     'error',
    //     (e: Event) => {
    //         const target = e.target as HTMLImageElement
    //         if (target.tagName !== 'IMG') return
    //         if (!target.getAttribute('data-error-handled')) {
    //             target.setAttribute('data-error-handled', 'true')
    //             target.src = fallbackSrc
    //         }
    //     },
    //     true, // 捕获阶段，确保能监听到 img 加载失败
    // )
})
