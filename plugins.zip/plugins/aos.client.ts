// plugins/aos.client.ts
import AOS from 'aos'
import 'aos/dist/aos.css'
import { defineNuxtPlugin } from '#app'

export default defineNuxtPlugin(nuxtApp => {
    nuxtApp.hook('app:mounted', () => {
        AOS.init({
            offset: 40, // 触发偏移
            delay: 0, // 全局延迟
            duration: 400, // 全局动画持续时间
            easing: 'ease', // 缓动类型
            once: false, // 每次滚动都触发（false）或只触发一次（true）
            mirror: false, // 滚动回去时是否反向触发动画
            anchorPlacement: 'top-bottom', // 动画触发位置
        })

        // AOS 需要刷新以识别 DOM
        setTimeout(() => {
            AOS.refresh()
        }, 300)
    })
})
