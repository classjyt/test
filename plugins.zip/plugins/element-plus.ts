// plugins/element-plus.ts
import ElementPlus from 'element-plus'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import en from 'element-plus/es/locale/lang/en'
import { defineNuxtPlugin } from 'nuxt/app'
import { watch } from 'vue'

// Nuxt 插件格式
export default defineNuxtPlugin(nuxtApp => {
    const getElementLocale = () => {
        const current = nuxtApp.$i18n.locale.value
        return current === 'en' ? en : zhCn
    }

    // 初始化绑定语言
    nuxtApp.vueApp.use(ElementPlus, {
        locale: getElementLocale(),
    })

    // 响应式监听语言变化（可选）
    nuxtApp.hook('app:mounted', () => {
        watch(
            () => nuxtApp.$i18n.locale.value,
            newLocale => {
                const newLang = newLocale === 'en' ? en : zhCn
                nuxtApp.vueApp.config.globalProperties.$ELEMENT = {
                    locale: newLang,
                }
            },
        )
    })
})
