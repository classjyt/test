import { useHttp } from "#imports";
import { useFetch } from "nuxt/app"

class CommonService {
    async queryInfo(params = {
        websiteCode: 3,
    }) {
        return useHttp(`/website/location/websiteTree`, params)
    }

    async queryCompanyInfo(params) {
        return useHttp(`/website/company/getCompanyInfo`, params)
    }

    async querySpecialDateList() {
        return useHttp(`/website/specialDate/selectSpecialDateList`, {})
    }
}

export default new CommonService()