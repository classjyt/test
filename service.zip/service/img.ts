import { httpGet, useHttp } from '#imports'

export interface IQueryImg {
    pageNum: number
    pageSize: number
    keyword: string
    status: number
    locationCodes?: string
    websiteCode?: string
}

export interface IImgProps {
    appImgUrl: string
    pcImgUrl: string
    subtitle: string
    title: number
}

export interface IListImg {
    createId: string
    createName: string
    updateId: string
    updateName: string
    createTime: string
    updateTime: string
    locationCodes: string
    locationNames: string
    id: number
    sort: number
    title: string
    linkUrl: string
    pcImgUrl: string
    appImgUrl: string
    status: number
    remark: string
}


class ImgService {
    //图片分页信息
    queryImgList(params: IQueryImg) {
        return useHttp(`/website/img/querySimpleImgList`, params)
    }

    //图片详情
    imgDetail(params: number) {
        return httpGet(`/website/imgDetail/querySimpleImgList`, params)
    }

    //图片分页信息(多位置code)
    querySimpleImgListByCodes(params: Array<IQueryImg>) {
        return useHttp(`/website/img/querySimpleImgListByCodes`, params)
    }
}

export default new ImgService()
