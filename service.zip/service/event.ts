import { httpGet, useHttp } from '#imports'

export interface IQueryEvent {
    pageNum: number
    pageSize: number
    keyword: string
    status: number
    year?: string
    locationCodes: string
    websiteCode?: string
}

export interface IListEvent {
    createId: string
    createName: string
    updateId: string
    updateName: string
    createTime: string
    updateTime: string
    id: number
    year: string
    month: string
    pushTime: string
    locationCodes: string
    locationNames: string
    content: string
    status: number
}

export interface IQueryWebsiteEventList {
    locationCodes: string
}


class EventService {
    // 大事记分页信息
    queryEventList(params: IQueryEvent) {
        return useHttp(`/website/event/queryEventList`, params)
    }

    // 大事记详情信息
    queryEventDetail(params: number) {
        return httpGet(`/website/event/EventDetail`, params)
        // return request({
        //     url: `${BASE_URL.EVENT}/EventDetail?${qs.stringify(params)}`,
        //     method: 'get',
        // })
    }

    // 大事记信息
    queryWebsiteEventList(params: IQueryWebsiteEventList) {
        return useHttp(`/website/event/queryWebsiteEventList`, params)
    }
}

export default new EventService()
