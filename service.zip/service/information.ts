import { httpGet, useHttp } from '#imports'

export interface IQueryInfo {
    pageNum: number
    pageSize: number
    keyword: string
    status: number
    locationCodes?: string
    websiteCode?: string
}

export interface ISaveInfo {
    id?: number | string
    status?: string
    websiteCode?: string
    content?: string
    title: string
    subtitle: string
    excerpt: string
    coverUrl: string
    pushTime: string
    locationCodes: string[]

}

export interface IUpdateInfo {
    id: number
    status: number
}

export interface IListInfo {
    id: number
    title: string
    subtitle: string
    locationCodes: string
    locationNames: string
    coverUrl: string
    content: string
    status:number
    excerpt: string
    pushTime: string
    updateName: string
    updateTime: string
}

class InformationService {
    // 信息管理分页信息
    queryInformationList(params: IQueryInfo) {
        return useHttp(`/website/information/queryInformationList`, params)
    }

    // 信息管理详情信息
    informationDetail(params: {id: number}) {
        return httpGet(`/website/information/InformationDetail`, params)
    }

    // 信息管理详情信息-根据code
    queryInformationDetailByCode(params: {code: string, locationCode: string}) {
        return httpGet(`/website/information/informationDetailByCode`, params)
    }

    // 信息管理分页信息-外部查询
    outQueryInformationList(params: IQueryInfo) {
        return useHttp(`/website/information/outQueryInformationList`, params)
    }

    // 隐私页面
    protocolList(type: string) {
        return httpGet(`/component/protocol/list`,{ type: type })
    }

    getLatestVersion(){
        return httpGet(`/oss/version/getLatestVersion`, { appType: '5' })
    }

    getIOSApp(type: string){
        return httpGet(`/henglink/redeemCode/findOne`, { type: type })
    }

}

export default new InformationService()
