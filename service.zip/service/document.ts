import { httpGet, useHttp } from '#imports'

export interface IQueryInfo {
    pageNum: number
    pageSize: number
    keyword: string
    status: number
    locationCodes?: string
    websiteCode?: string
}

class DocumentService {
    // pdf分页信息
    queryDocumentList(params: IQueryInfo) {
        return useHttp(`/website/document/querySimpleDocumentList`, params)
    }
}

export default new DocumentService()
