import type { ComputedRef, MaybeRef } from 'vue'
export type LayoutKey = "about-layout" | "contact-layout" | "default" | "detail-layout" | "development-layout" | "download-layout" | "news-layout" | "party-building-layout" | "product-layout" | "social-welfare-layout"
declare module 'nuxt/app' {
  interface PageMeta {
    layout?: MaybeRef<LayoutKey | false> | ComputedRef<LayoutKey | false>
  }
}