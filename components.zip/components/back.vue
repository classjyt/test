<template>
    <div class="h-bg-[#F1F4F9]">
        <div
            class="common-wrap h-flex h-items-center h-text-sm h-cursor-pointer  h-h-[60px]"
            @click="
                () => {
                    router.go(-1)
                }
            ">
            <span class="iconfont icon-arrow-left-s-fill !h-text-2xl"></span>
            <div class="h-ml-1">返回</div>
        </div>
    </div>
</template>

<script setup>
// import { useRouter } from 'vue-router';

// 设置页面元信息
definePageMeta({
    layout: 'default',
    // 如果需要默认重定向到product页面
    middleware: [
        ({ path }) => {
            if (path === '/news') {
                return navigateTo('/news/company-news')
            }
        },
    ],
})
const router = useRouter()
</script>
