<script setup lang="ts">
import { onMounted, ref } from 'vue'

const mapEl = ref<HTMLDivElement | null>(null)

function loadTencentMapScript(): Promise<void> {
    return new Promise((resolve, reject) => {
        if (window.TMap) return resolve()

        const script = document.createElement('script')
        script.src = 'https://map.qq.com/api/gljs?v=1.exp&key=2VFBZ-DJ6YW-BUSRO-Y3P6Y-LIWNQ-XRF7H'
        script.onload = () => resolve()
        script.onerror = reject
        document.head.appendChild(script)
    })
}

onMounted(async () => {
    await loadTencentMapScript()

    const map = new window.TMap.Map(mapEl.value!, {
        zoom: 16,
        center: new window.TMap.LatLng(39.509330, 121.318065), // 上海
    })

    new window.TMap.MultiMarker({
        map,
        geometries: [
            {
                id: 'marker1',
                styleId: 'style1',
                position: new window.TMap.LatLng(39.509330, 121.318065),
                properties: {
                    title: '上海市',
                },
            },
        ],
    })
})
</script>

<template>
    <div
        ref="mapEl"
        class="w-full h-[400px]" />
</template>
