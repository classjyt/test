<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { CountUp } from 'countup.js'

const props = defineProps<{
    end: number
    start?: number
    duration?: number
    decimals?: number
    prefix?: string
    suffix?: string
    separator?: string // 千分位分隔符，例如 ','，可自定义
}>()

const el = ref<HTMLElement | null>(null)
let countUp: CountUp
let observer: IntersectionObserver

const createCountUp = () => {
    if (!el.value) return

    countUp = new CountUp(el.value, props.end, {
        startVal: props.start ?? 0,
        duration: props.duration ?? 2,
        decimalPlaces: props.decimals ?? 0,
        prefix: props.prefix ?? '',
        suffix: props.suffix ?? '',
        separator: props.separator ?? ',',
    })
}

const start = () => {
    if (!countUp) createCountUp()
    if (countUp?.error) {
        console.error(countUp.error)
    } else {
        countUp?.reset()   // 每次可见时重置
        countUp?.start()   // 再启动
    }
}

const observe = () => {
    if (!el.value) return

    observer = new IntersectionObserver(
        ([entry]) => {
            if (entry.isIntersecting) {
                // 进入视口 -> 执行动画
                start()
            } else {
                // 离开视口 -> 清零
                countUp?.reset()
            }
        },
        {
            threshold: 0.6, // 元素可见 60% 时触发
        },
    )

    observer.observe(el.value)
}

onMounted(() => {
    observe()
})

onBeforeUnmount(() => {
    observer?.disconnect()
})

watch(
    () => props.end,
    newVal => {
        if (countUp) countUp.update(newVal)
    },
)
</script>

<template>
    <span ref="el" />
</template>
