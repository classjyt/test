<template>
    <footer class="h-bg-footer">
        <div class="common-wrap h-flex h-flex-col md:h-flex-row md:h-justify-between h-items-start h-pt-10 h-pb-[28px] h-text-white h-text-sm">
            <div class="h-flex h-flex-col h-flex-1 md:h-mr-5">
                <div class="h-grid h-grid-cols-1 h-gap-8">
                    <!-- Logo 和 名称 -->
                    <div>
                        <div class="h-flex h-items-center h-space-x-2 h-mb-4">
                            <NuxtImg
                                width="250px"
                                src="/images/logo.svg"
                                class="h-object-contain" />
                        </div>
                    </div>
                </div>

                <div class="h-flex h-flex-col h-mt-5 h-space-y-1.5">
                    <div>{{ t('common.address') }}：{{ companyInfo.companyAddr }}</div>
                    <div>{{ t('common.phone') }}：{{ companyInfo.telephoneNumber }}</div>
                    <!-- <div>{{ t("common.fax") }}：{{ companyInfo.faxNumber }}</div> -->
                    <div>{{ t('common.email') }}：{{ companyInfo.reportMailbox }}</div>
                </div>
            </div>

            <div class="h-mt-8 md:h-mt-0 h-flex h-items-center">
                <NuxtImg
                    v-if="companyInfo.weiboQrCode"
                    width="100"
                    height="100"
                    :src="companyInfo.weiboQrCode"
                    class="h-object-fill" />
                <NuxtImg
                    v-if="companyInfo.publicNumberQrCode"
                    width="100"
                    height="100"
                    :src="companyInfo.publicNumberQrCode"
                    class="h-object-fill h-ml-5" />
            </div>
        </div>

        <div class="h-w-full h-h-[1px] h-bg-grey"></div>

        <div class="common-wrap h-box-content h-mx-auto h-flex h-flex-col lg:h-flex-row md:h-justify-between md:h-items-center h-gap-3 h-px-4 md:h-px-10 h-text-xs h-text-grey h-overflow-hidden h-break-words h-py-4">
            <div class="xl:h-w-2/5">
                {{ t('footer.copyright', { year: new Date().getFullYear() }) }}
            </div>
            <div class="h-flex h-flex-col xl:h-w-3/5 md:h-flex md:h-flex-row md:h-items-center h-gap-3 md:h-gap-10 h-break-all">
                <a class="xl:h-w-1/2" target="_blank" href="https://beian.miit.gov.cn/#/Integrated/index">
                    {{ companyInfo.icpRecordNumber }}
                </a>
                <a v-if="companyInfo.publicSecurityRecordNumber" class="h-flex h-items-center xl:h-w-1/2" target="_blank" :href="`http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=${companyInfo.publicSecurityRecordNumber}`">
                    <NuxtImg
                        src="/images/police.png"
                        width="20"
                        height="20"
                        class="h-mr-1" />
                    {{ companyInfo.publicSecurityRecordNumber }}
                </a>
            </div>
        </div>

        <div class="h-bg-footer-second h-text-xs h-text-[12px] h-hidden sm:h-block">
            <div class="common-wrap h-box-content h-mx-auto h-py-4 h-flex h-flex-col h-text-[#C1C7CD] h-leading-5 h-text-center h-px-4 md:h-px-10 xl:h-flex-col md:h-gap-1 xl:h-gap-0">
                <div class="h-whitespace-pre-wrap">{{ companyInfo.disclaimer }}</div>
            </div>
        </div>
    </footer>
</template>

<script setup lang="ts">
import { NuxtImg } from '#components'
import { useFooterStore, useI18n, storeToRefs } from '#imports'

const { t } = useI18n()
const footerStore = useFooterStore()
const { companyInfo } = storeToRefs(footerStore)
</script>
