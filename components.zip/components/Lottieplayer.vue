<script setup lang="ts">
import lottie from 'lottie-web'
import { onMounted, onBeforeUnmount, ref } from 'vue'

const props = defineProps<{
    src: string // JSON 动画路径（本地或远程）
    loop?: boolean
    autoplay?: boolean
}>()

const container = ref<HTMLElement>()

let animation: any = null

onMounted(() => {
    animation = lottie.loadAnimation({
        container: container.value!,
        renderer: 'svg',
        loop: props.loop ?? true,
        autoplay: props.autoplay ?? true,
        path: props.src,
    })
})

onBeforeUnmount(() => {
    animation?.destroy()
})
</script>

<template>
    <div
        ref="container"
        class="w-full h-full" />
</template>
