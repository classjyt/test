<template>
    <section class="sub-nav-wrap h-w-full h-z-50 h-h-[360px] md:h-h-[600px] h-bg-transparent h-relative">
        <ElCarousel
            trigger="click"
            height="100%"
            class="h-relative h-h-full h-w-full h-overflow-hidden"
            indicator-position="none"
            :arrow="bannerList.length > 1 ? 'hover' : 'never'">
            <ElCarouselItem
                v-for="(item, index) in bannerList"
                :key="index"
                class="h-w-full h-h-full h-relative">
                <!-- <NuxtImg
                    priority
                    class="h-w-full h-h-full h-object-cover"
                    :src="item.pcImgUrl" /> -->
                <LottieImage
                    priority
                    class="h-w-full h-h-full h-object-cover"
                    :src="item.pcImgUrl" />
            </ElCarouselItem>
        </ElCarousel>
    </section>

    <div
        v-if="level2?.name"
        class="common-wrap h-flex h-items-center h-mt-6 h-text-sm h-leading-6 h-select-none">
        <div class="h-text-secondary">{{ level1?.menuName }}</div>
        <div class="h-text-secondary h-mx-2">
            <span class="iconfont icon-a-Arrow-right3"></span>
        </div>
        <div class="h-text-main">{{ level2?.menuName }}</div>
    </div>
</template>

<script setup lang="ts">
import { PropType, computed, ref } from 'vue'
import { ElCarousel, ElCarouselItem, NuxtImg } from '#components'
import { useRoute, useRouter } from 'vue-router'
import { useHeaderStore, storeToRefs } from '#imports'

defineProps({
    title: {
        type: String,
        default: '未设置',
    },
    navList: {
        type: Array as PropType<any[]>,
        default: () => [],
    },
    bannerList: {
        type: Array as PropType<any[]>,
        default: () => [],
    },
})

const props = defineProps<{ title: string; navList: any[]; bannerList: any[] }>()

const headerStore = useHeaderStore()
const { menuList } = storeToRefs(headerStore)

const route = useRoute()
const router = useRouter()

const currentNavIndex = computed(() => {
    return props.navList?.findIndex(item => route.path?.includes(item.path))
})

const level1 = computed(() => {
    return menuList.value?.find(item => {
        const routePath = route.path?.split('/')[2]
        return item.href?.includes(routePath)
    })
})

const level2 = computed(() => {
    return level1.value?.itemMenuList?.find(item => {
        return route.path?.includes(item.href)
    })
})
</script>

<style scoped>
.sub-nav-wrap {
    .item {
        @apply h-opacity-60;

        &.active {
            @apply h-font-medium h-opacity-100;

            .item-current {
                @apply h-font-medium;
                border-color: #fff;
            }
        }

        &:nth-child(3) {
            @apply h-w-full md:h-w-auto h-flex h-justify-center;

            .item-current {
                width: 280px;
            }
        }

        &:first {
            .item-current {
                @apply h-mr-5;
            }
        }

        .item-current {
            @apply h-py-3 h-flex h-items-center h-justify-center h-h-12 h-border-b-2 h-text-sm h-leading-6 h-cursor-pointer;
            color: #eee;
            width: 130px;
            border-color: #eee;            

            @apply md:!h-w-[132px] md:h-h-[60px] md:h-text-sm;

            .sub-title {
                @apply h-mr-3;
            }

            .icon {
                font-size: 20px;
                width: 20px;
                height: 20px;
            }
        }
    }
}
</style>
