<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount, nextTick } from 'vue'
import lottie from 'lottie-web'

const props = defineProps<{
    src: string
    alt?: string
    width?: string | number
    height?: string | number
    loadingAnimation: string
    errorImage: string
    priority?: boolean
}>()

const isLoading = ref(true)
const isError = ref(false)
const lottieContainer = ref<HTMLElement | null>(null)
const wrapperRef = ref<HTMLElement | null>(null)

let animation: any = null

onMounted(async () => {
    if (lottieContainer.value) {
        animation = lottie.loadAnimation({
            container: lottieContainer.value,
            renderer: 'svg',
            loop: true,
            autoplay: true,
            path: props.loadingAnimation || '/animations/indexBanner.json',
        })
    }

    await nextTick()
    const realImg = wrapperRef.value?.querySelector('img') as HTMLImageElement | null
    if (realImg?.complete && realImg.naturalWidth > 0) {
        handleLoaded()
    }
})

onBeforeUnmount(() => {
    animation?.destroy()
})

function handleLoaded() {
    isLoading.value = false
}

function handleError() {
    isLoading.value = false
    isError.value = true
}
</script>

<template>
    <div
        ref="wrapperRef"
        class="h-relative h-inline-block h-overflow-hidden"
        :style="{ width: typeof width === 'number' ? `${width}px` : width, height: typeof height === 'number' ? `${height}px` : height }">
        <!-- Lottie loading -->
        <div
            v-if="isLoading"
            class="h-absolute h-inset-0 h-z-10 h-flex h-items-center h-justify-center h-bg-white/70">
            <div
                ref="lottieContainer"
                class="w-full h-full"></div>
        </div>

        <!-- error fallback -->
        <NuxtImg
            v-show="isError"
            :src="errorImage || '/images/placeholder.png'"
            :alt="alt"
            :width="width"
            :height="height"
            class="h-object-cover h-w-full h-h-full" />

        <!-- image -->
        <NuxtImg
            v-show="!isError"
            :src="src"
            :alt="alt"
            :width="width"
            :height="height"
            :format="src?.includes('gif') ? 'gif' : undefined"
            class="h-object-cover h-w-full h-h-full h-transition-opacity h-duration-300"
            @load="handleLoaded"
            @error="handleError"
            loading="lazy"
            :priority="priority" />
    </div>
</template>
