import { computed, ref } from 'vue'
import { ElMenu, ElSubMenu, NuxtImg, NuxtLink } from '#components'
import { defineNuxtComponent, useNuxtApp, useRoute } from 'nuxt/app'
import { storeToRefs, useHeaderStore, useI18n, useScreen, useScroll } from '#imports'
import CommonService from '~/service/common'
import './index.css'

export default defineNuxtComponent({
    name: 'Header',

    props: {
        isScrolled: () => {},
    },

    async setup(props) {
        const { $i18n }: any = useNuxtApp()
        const locale = $i18n.locale.value
        const headerStore = useHeaderStore()
        const route = useRoute()
        const { menuList } = storeToRefs(headerStore)
        const { updateMenuList } = headerStore
        const isHover = ref(false)
        const isOpen = ref(false)
        const isDetail = computed(() => route.path?.includes('detail'))

        const { getSize } = useScreen()

        const filterMenuList = computed(() => {
            let listByLang = menuList.value?.filter(item => {
                if (route.path?.includes('zh')) {
                    // 过滤社会公益
                    return item.code !== '9bI0W4F2'
                } else {
                    // 过滤党建
                    return item.code !== '5c2V9nR6'
                }
            })
            // console.log('listByLang :>> ', listByLang);
            // return listByLang
            if (locale !== 'zh') {
                const workObj = listByLang?.find(item => item.code === '3H8j4pX7') // 招聘
                listByLang = listByLang?.filter(item => !['3H8j4pX7', '8K7mT3gB'].includes(item.code)) // 非中文过滤 招聘、联系我们
                for (const item of listByLang) {
                    if (item.code === '9X5vN3rJ') {
                        if (item.itemMenuList?.every(subItem => subItem.code !== '3H8j4pX7')) {
                            item.itemMenuList?.push(workObj)
                        }
                    }
                }
            }
            return listByLang
            if (getSize() === 'xl') {
                const mainMenuList = listByLang?.slice(0, 4)
                const subMenuList = listByLang?.splice(4, 7)
                const menuList = [
                    ...mainMenuList,
                    {
                        menuName: '更多',
                        href: '',
                        code: '',
                        itemMenuList: subMenuList,
                    },
                ]
                // console.log('111111111 :>> ', menuList)
                return menuList
            } else {
                // console.log('222222222 :>> ', 222222222)
                return listByLang
            }
        })

        const { top, isScrolled } = useScroll()

        const isShowHeaderBgWhite = computed(() => isHover.value || isScrolled.value || isOpen.value || isDetail.value || props.isScrolled)

        return () => (
            <header
                class={['header h-fixed h-top-0 h-left-0 h-w-full h-z-[2000] h-h-[60px] md:h-h-20 h-bg-transparent h-transition-colors nav-wrap', isHover.value ? 'hover' : '', isScrolled.value || props.isScrolled ? 'scroll' : '', isOpen.value ? 'open-nav' : '', isDetail.value ? 'scroll' : '']}
                // onMouseover={() => (isHover.value = true)}
                // onMouseout={() => (isHover.value = false)}
                >
                <div class='common-wrap !h-overflow-visible h-mx-auto h-px-4 lg:h-px-10 h-h-full h-flex h-items-center h-justify-between'>
                    <NuxtLink
                        to='/'
                        onClick={() => (isOpen.value = false)}
                        class='h-flex h-min-w-[180px] lg:h-min-w-[126px] h-mr-5'>
                        <NuxtImg
                            src={isShowHeaderBgWhite.value ? '/images/logo-dark.svg' : '/images/logo-light.svg'}
                            class='h-h-8'
                        />
                    </NuxtLink>

                    {/* 导航栏 */}
                    <nav class='h-relative h-z-[2000] h-h-full lg:h-flex-1 h-hidden lg:h-items-center lg:h-justify-end xl:h-justify-end lg:h-flex lg:h-text-base xl:h-text-[18px] h-text-white'
                        onMouseover={() => (isHover.value = true)}
                        onMouseout={() => (isHover.value = false)}
                    >
                        {filterMenuList.value?.map(item => (
                            <div class={['nav-item h-relative', locale === 'zh' ? 'zh' : 'unzh', route.path?.split('/')?.[2] === item.href?.split('/')?.[1] ? 'active' : '']}>
                                <NuxtLink
                                    class="h-w-full h-h-full h-flex h-items-center h-justify-center"
                                    to={item.href}
                                    key={item.menuName}
                                    target={item.target}>
                                    {item.menuName}
                                </NuxtLink>
                                {
                                    <div class='sub-menu h-absolute lg:h-text-sm xl:h-text-base h-z-[2000] h-top-full h-left-0 h-w-full h-text-center h-flex-col'>
                                        {item?.itemMenuList?.map(subItem => (
                                            <div class='first:h-mt-8 h-mb-5 h-text-submain hover:h-text-primary h-cursor-pointer' onClick={() => isHover.value = false}>
                                                <NuxtLink 
                                                    class="h-w-full h-h-full" to={subItem.href} 
                                                    target={subItem.target}
                                                >{subItem.menuName}</NuxtLink>
                                            </div>
                                        ))}
                                    </div>
                                }
                            </div>
                        ))}
                        {/* 子导航 */}
                        <div class='sub-header-bg h-fixed h-z-[1500] h-top-20 h-left-0 h-w-full h-bg-[#FFFFFFD6] h-backdrop-blur-[20px] h-border-b'></div>
                    </nav>

                    <div class='xl:h-absolute md:h-top-0 md:h-right-6 lg:h-right-10 h-h-20 h-flex h-items-center'>
                        {/* <button
                            class='h-text-sm h-cursor-pointer h-text-white'
                            title='点击切换语言'>
                            中文
                        </button> */}
                        {/* Mobile menu button */}
                        <span
                            class={`lg:h-hidden h-cursor-pointer h-ml-4 icon-menu iconfont h-text-white !h-text-3xl ${isOpen.value ? 'icon-icon_h5guanbi' : 'icon-icon_menu'}`}
                            onClick={() => (isOpen.value = !isOpen.value)}></span>
                    </div>
                </div>
                {/* h-bg-[#00000011] h-backdrop-blur-2xl */}
                <div class='sub-header-bottom h-fixed h-z-[1400] h-top-20 h-left-0 h-w-full h-h-full h-bg-[#00000033] h-border-b'></div>

                {/* Mobile nav */}
                {isOpen.value && (
                    <nav class='phone-nav-wrap h-fixed h-top-[60px] md:h-top-20 h-left-0 h-w-full lg:h-hidden h-overflow-scroll h-no-scrollbar h-h-[calc(100vh-60px)] md:h-h-[calc(100vh-80px)] h-bg-white h-shadow-md h-text-sm h-text-main h-font-medium'>
                        <ElMenu class='!h-border-none'>
                            {filterMenuList.value.map((item, index) => {
                                if (item?.itemMenuList?.length) {
                                    return (
                                        <ElSubMenu
                                            index={index}
                                            class=''
                                            v-slots={{
                                                title: () => <el-menu-item class='!h-pl-0'>{item.menuName}</el-menu-item>,
                                            }}>
                                            {item?.itemMenuList?.map(subItem => (
                                                <el-menu-item class='!h-pl-8'>
                                                    <NuxtLink
                                                        class='h-w-full h-h-full'
                                                        to={subItem.href}
                                                        target={subItem.target}
                                                        onClick={() => (isOpen.value = false)}>
                                                        {subItem.menuName}
                                                    </NuxtLink>
                                                </el-menu-item>
                                            ))}
                                        </ElSubMenu>
                                    )
                                } else {
                                    return (
                                        <el-menu-item class='!h-pl-4'>
                                            <NuxtLink
                                                to={item.href}
                                                key={item.menuName}
                                                class='h-w-full h-h-full'
                                                onClick={() => (isOpen.value = false)}>
                                                {item.menuName}
                                            </NuxtLink>
                                        </el-menu-item>
                                    )
                                }
                            })}
                        </ElMenu>
                    </nav>
                )}
            </header>
        )
    },
})
