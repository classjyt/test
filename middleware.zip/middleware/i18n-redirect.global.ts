// middleware/i18n-redirect.global.ts
import { defineNuxtRouteMiddleware, navigateTo, useCookie, useRequestHeaders } from '#imports'
import { useRequestEvent } from 'nuxt/app'

// 项目支持的语言列表
const SUPPORTED_LANGUAGES = ['zh', 'en'] as const
type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number]
const DEFAULT_LANGUAGE: SupportedLanguage = 'zh'

export default defineNuxtRouteMiddleware(async to => {
    // console.log('to :>> ', to);

    // 1. 检查当前路径是否需要跳过重定向
    if (shouldSkipRedirect(to.path)) return
    // console.log('to :>> ', to);

    // 2. 获取用户首选语言
    const preferredLang = await detectPreferredLanguage()

    // 3. 获取当前路径中的语言部分
    const currentLang = getCurrentLanguageFromPath(to.fullPath)

    // 4. 如果当前语言无效或不支持
    if (currentLang && !isLanguageSupported(currentLang)) {
        return handleUnsupportedLanguage(currentLang, preferredLang, to.fullPath)
    }

    // 5. 如果路径缺少语言前缀
    if (!currentLang) {
        return handleMissingLanguagePrefix(preferredLang, to.fullPath)
    }

    // 6. 设置语言cookie（用于后续请求）
    setLanguageCookie(preferredLang)
})

/**
 * 检测用户首选语言
 */
async function detectPreferredLanguage(): Promise<SupportedLanguage> {
    // 优先级1: 检查cookie中存储的语言偏好
    const langCookie = useCookie<SupportedLanguage>('i18n_preferred_lang')
    if (langCookie.value && isLanguageSupported(langCookie.value)) {
        return langCookie.value
    }

    // 优先级2: 从路径参数获取
    const pathLang = getCurrentLanguageFromPath(useRequestPath())
    if (pathLang && isLanguageSupported(pathLang)) {
        return pathLang as SupportedLanguage
    }

    // 优先级3: 从浏览器语言设置获取
    const browserLang = detectBrowserLanguage()
    if (browserLang) return browserLang

    // 优先级4: 从Accept-Language头部获取（仅服务端）
    if (process.server) {
        const headers = useRequestHeaders(['accept-language'])
        const acceptLanguage = headers['accept-language']
        if (acceptLanguage) {
            const lang = parseAcceptLanguage(acceptLanguage)
            if (lang) return lang
        }
    }

    // 默认语言
    return DEFAULT_LANGUAGE
}

/**
 * 检测浏览器语言设置
 */
function detectBrowserLanguage(): SupportedLanguage | null {
    if (process.client && navigator) {
        const languages = navigator.languages || [navigator.language]

        for (const lang of languages) {
            const code = lang.split('-')[0].toLowerCase()
            if (isLanguageSupported(code)) {
                return code as SupportedLanguage
            }
        }
    }
    return null
}

/**
 * 解析Accept-Language头部
 */
function parseAcceptLanguage(header: string): SupportedLanguage | null {
    const languages = header
        .split(',')
        .map(lang => {
            const [code, q = '1'] = lang.trim().split(';q=')
            return { code: code.split('-')[0].toLowerCase(), q: parseFloat(q) }
        })
        .sort((a, b) => b.q - a.q)

    for (const { code } of languages) {
        if (isLanguageSupported(code)) {
            return code as SupportedLanguage
        }
    }
    return null
}

/**
 * 检查语言是否受支持
 */
function isLanguageSupported(lang: string): lang is SupportedLanguage {
    return SUPPORTED_LANGUAGES.includes(lang as any)
}

/**
 * 从路径中提取当前语言
 */
function getCurrentLanguageFromPath(path: string): string | null {
    const segments = path.split('/').filter(Boolean)
    // console.log('segments :>> ', segments);
    return segments.length > 0 && isLanguageSupported(segments[0]) ? segments[0] : null
}

/**
 * 处理不支持的语言
 */
function handleUnsupportedLanguage(currentLang: string, preferredLang: SupportedLanguage, path: string) {
    // 构建新路径：替换无效语言前缀
    const newPath = path.replace(`/${currentLang}`, `/${preferredLang}`)

    return navigateTo(newPath, {
        redirectCode: 301,
        external: false,
    })
}

/**
 * 处理缺失语言前缀
 */
function handleMissingLanguagePrefix(preferredLang: SupportedLanguage, path: string) {
    // 构建新路径：添加语言前缀
    const newPath = `/${preferredLang}${path === '/' ? '' : path}`

    return navigateTo(newPath, {
        redirectCode: 302,
        external: false,
    })
}

/**
 * 设置语言cookie
 */
function setLanguageCookie(lang: SupportedLanguage) {
    const cookie = useCookie('i18n_preferred_lang', {
        maxAge: 60 * 60 * 24 * 365, // 1年
        sameSite: 'lax',
        path: '/',
    })

    if (cookie.value !== lang) {
        cookie.value = lang
    }
}

/**
 * 检查是否应跳过重定向
 */
function shouldSkipRedirect(path: string): boolean {
    // 跳过API路径
    if (path.startsWith('/api')) return true

    // 跳过静态资源
    if (path.startsWith('/_')) return true

    // 跳过已包含语言前缀的路径
    if (getCurrentLanguageFromPath(path)) return true

    // 跳过特定路径（可选配置）
    const skipPaths = ['/login', '/register', '/auth', '/sitemap.xml']
    if (skipPaths.includes(path)) return true

    // 跳过文件扩展名路径
    if (/\.[a-z0-9]+$/i.test(path)) return true

    return false
}

/**
 * 获取请求路径（不含查询参数）
 */
function useRequestPath(): string {
    if (process.server) {
        const req = useRequestEvent()?.node?.req
        return req?.url?.split('?')[0] || '/'
    }
    return window.location.pathname
}
