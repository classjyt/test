// server/middleware/security-headers.ts
import type { H3Event } from 'h3'

export default function securityHeaders() {
    return async (event: H3Event) => {
        event.node.res.setHeader('X-Frame-Options', 'DENY')
        // event.node.res.setHeader('Strict-Transport-Security', 'max-age=86400; includeSubDomains')
        event.node.res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' https://cdn.example.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none';")
    }
}
