// composables/useScroll.ts
import { ref, onMounted, onUnmounted } from 'vue'

export const useScroll = () => {
    const top = ref<number>(0)

    const isScrolled = ref(false)

    const onWindowScroll = () => {
        // console.log('滚动了 :>> 哈哈哈哈')
        top.value = window?.scrollY || 0
        isScrolled.value = window?.scrollY > 0
    }
    const scrollToTop = (behavior: ScrollBehavior = 'smooth') => {
        if (typeof window === 'undefined') return
        window.scrollTo({ top: 0 })
    }

    onMounted(() => {
        if (typeof window === 'undefined') return
        window.addEventListener('scroll', onWindowScroll)
    })

    onUnmounted(() => {
        if (typeof window === 'undefined') return
        window.removeEventListener('scroll', onWindowScroll)
    })

    return {
        top,
        isScrolled,
        onWindowScroll,
        scrollToTop,
    }
}
