// composables/useElScrollbarScroll.ts
import { ref, onMounted, onUnmounted } from 'vue'

export const useElScrollbarScroll = () => {
    const top = ref(0)
    const isScrolled = ref(false)

    // 用于绑定 ElScrollbar 的 ref
    const scrollbarRef = ref<any>(null)

    // 滚动事件处理函数
    const onScroll = (e: HTMLElement) => {
        console.log('e :>> ', e);
        // const target = e?.target as HTMLElement
        top.value = e?.scrollTop ?? 0
        // console.log('target?.scrollTop :>> ', target?.scrollTop);
        console.log('top.value :>> ', top.value);
        isScrolled.value = top.value > 0
        console.log('isScrolled.value :>> ', isScrolled.value);
    }

    // 手动注册 scroll 事件（可选，如果不使用 @scroll）
    onMounted(() => {
        if (scrollbarRef.value?.wrapRef) {
            // scrollbarRef.value.wrapRef.addEventListener('scroll', onScroll)
        }
    })

    onUnmounted(() => {
        if (scrollbarRef.value?.wrapRef) {
            // scrollbarRef.value.wrapRef.removeEventListener('scroll', onScroll)
        }
    })

    return {
        top,
        isScrolled,
        scrollbarRef,
        onScroll, // 也暴露出来，便于用 @scroll 绑定
    }
}
